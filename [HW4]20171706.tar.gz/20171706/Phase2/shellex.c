/* $begin shellmain */
#include "csapp.h"
#include<errno.h>
#define MAXARGS   128

// structure
typedef struct background {
	int num;
	pid_t pid;
	char operand;
	char status[50];
	char cmdline[MAXLINE];
	struct background* next;
}bglist;

/* Function prototypes */
void eval(char* cmdline);
int parseline(char* buf, char** argv);
int builtin_command(char** argv);
void usepipe(char* cmdline);
void sigchildhandler(int signal);
void sig_c_handler(int sig);
void sig_z_handler(int signal);
void append_list(char* cmdline, int flag, pid_t pid);
void append_cmd_order(int num);
void print_done();
void bglist_update();
void cmd_fg(char* number);
void cmd_bg(char* number);
void cmd_kill(char* number);
void cmd_jobs(char** argv);
void fgwait(char* cmdline, pid_t pid);
int clear_buffer();
void pipe_flag_append(pid_t pid);

int red_out, red_in, bg_count = 0, cnt = 0;
int cat_flag = 0, flag_pipe = 0, z_flag = 0;;
int cur_fg_flag = 0;
char pipecmd[MAXLINE];
bglist* bg = NULL;
pid_t fore_pid = -1;
pid_t parent_pid = -1;

int main()
{
	char cmdline[MAXLINE]; /* Command line */
	char cmd_check[100];
	signal(SIGINT, (void*)sig_c_handler);
	signal(SIGTSTP, (void*)sig_z_handler);
	signal(SIGCHLD, sigchildhandler);


	red_out = dup(STDOUT_FILENO);
	red_in = dup(STDIN_FILENO);
	while (1) {
		/* Read */
		printf("CSE4100-SP-P#4> ");
		fgets(cmdline, MAXLINE, stdin);
		if (feof(stdin))
			exit(0);
		strcpy(cmd_check, cmdline);
		strtok(cmd_check, " ");
		if (!strcmp(cmd_check, "cat") || !strcmp(cmd_check, "cat\n") || !strcmp(cmd_check, "less")) {
			cat_flag = -1;
		}
		if (cat_flag == 2) {
			setpgid(parent_pid, 0);
		}
		/* Evaluate */
		print_done();
		bglist_update();
		if (cmdline[strlen(cmdline) - 2] == '&' && cmdline[strlen(cmdline) - 2] != ' ') {
			cmdline[strlen(cmdline) - 2] = '\0';
			strcat(cmdline, " &\n\0");
		}
		eval(cmdline);
		if (bg == NULL)
			bg_count = 0;
		flag_pipe = 0;
		cur_fg_flag = 0;
		clear_buffer();
	}
}
/* $end shellmain */

int clear_buffer() {
	int result;
	fflush(stdin);
	if((result = close(STDIN_FILENO)) < 0)
		return -1;
	if ((result = dup2(red_in, STDIN_FILENO)) < 0)
		return -1;
	return 0;
}

/* $begin eval */
/* eval - Evaluate a command line */
void eval(char* cmdline)
{
	char* argv[MAXARGS]; /* Argument list execve() */
	char buf[MAXLINE];
	int bg;              /* Should the job run in bg or fg? */
	pid_t pid;
	char path[1024];
	char* pipeline = strchr(cmdline, '|');
	int flag = 0;
	int error_flag = 0;
	strcpy(buf, cmdline);
	bg = parseline(buf, argv);
	if (argv[0] == NULL)
		return;   /* Ignore empty lines */
	if (!builtin_command(argv)) { //quit -> exit(0), & -> ignore, other -> run
		if (pipeline == NULL) {
			if ((pid = Fork()) == 0) {
				if (cat_flag != -1) {
					setpgid(0, 0);
					cat_flag = 2;
				}
				if (execvp(argv[0], argv) < 0) {	//ex) /bin/ls ls -al &
					printf("%s: Command not found.\n", argv[0]);
					error_flag = 1;
					exit(0);
				}
			}
			if (flag == 0) {
				parent_pid = getpid();
				flag = 1;
			}
			/* Parent waits for foreground job to terminate */
			if (!bg) {
				fore_pid = pid;
				cur_fg_flag = 1;
				fgwait(cmdline, pid);
				z_flag = 1;
			}
			else { //when there is backgrount process!
				if(error_flag == 1)
					append_list(cmdline, 2, pid);
				else
					append_list(cmdline, 0, pid);
			}
		}
		else {
			strcpy(pipecmd, cmdline);
			usepipe(cmdline);
		}
	}
	return;
}

void usepipe(char* cmdline) {
	char* argv1[MAXARGS];//���ʸ��ɾ�
	char* argv2[MAXARGS];//���ʸ��ɾ�
	char fst_cmd[MAXLINE];
	char next_cmd[MAXLINE];
	char buf[1000];
	pid_t pid1, pid2;
	int fd[2], bg, status1, status2;
	fflush(stdin);
	if (strchr(cmdline, '|') != NULL) {//������ ����ϴ� ���

		strcpy(fst_cmd, strtok(cmdline, "|"));
		strcpy(next_cmd, strtok(NULL, ""));
		strcat(fst_cmd, "\n\0");
		bg = parseline(fst_cmd, argv1);
		if (pipe(fd) == -1) {//������ ����   fd[0] �б��, fd[1] �����
			printf("fail to call pipe()\n");
			exit(1);
		}

		if ((pid1 = Fork()) == 0) {
			if (cat_flag != -1 && cat_flag != 2) {
				setpgid(0, 0);
				cat_flag = 2;
			}

			dup2(fd[1], STDOUT_FILENO);
			close(fd[0]);
			close(fd[1]);

			if (execvp(argv1[0], argv1) < 0) {
				printf("%s: Command not found.\n", argv1[0]);
				exit(0);
			}
		}

		if (flag_pipe == 0) {
			parent_pid = getpid();
			flag_pipe = 1;
			if (pipecmd[strlen(pipecmd) - 2] == '&') {
				printf("%s", pipecmd);
				append_list(pipecmd, 0, pid1);
			}
		}

		dup2(fd[0], STDIN_FILENO);
		close(fd[0]); close(fd[1]);

		if (strchr(next_cmd, '|') != NULL)
			usepipe(next_cmd);
		else {
			bg = parseline(next_cmd, argv2);
			if ((pid2 = Fork()) == 0) {
				if (execvp(argv2[0], argv2) < 0) {	//ex) /bin/ls ls -al &
					printf("%s: Command not found.\n", argv2[0]);
					exit(0);
				}
			}
			if (!bg) {
				fore_pid = pid2;
				fgwait(cmdline, pid2);
			}
			else {
				dup2(red_in, STDIN_FILENO);
			}
		}
	}
}

void fgwait(char* cmdline, pid_t pid) {
	bglist* mov = NULL;
	pid_t re_pid = -1;
	int flag = -1;
	int status;
	for (mov = bg; mov != NULL; mov = mov->next) {
		if (mov->pid = pid) {
			break;
		}
	}
	if (mov == NULL) {
		if (waitpid(pid, &status, WUNTRACED) > 0) {
			if (WIFSTOPPED(status)) {
				append_list(cmdline, 1, pid);
				return;
			}
		}
	}
	if (mov != NULL) {
		strcpy(mov->status, "Stopped");
		printf("\n[%d]%c\t%s", mov->num, mov->operand, mov->cmdline);
	}
}

void sigchildhandler(int signal) {
	int status;
	bglist* mov;
	pid_t pid = -1;
	while ((pid = waitpid(-1, &status, WNOHANG)) > 0) {
		if (!WIFSTOPPED(status)) {
			for (mov = bg; mov != NULL; mov = mov->next) {
				if (mov->pid == pid && strcmp(mov->status, "Terminated")) {
					strcpy(mov->status, "Done");
				}
			}
		}
	}
}

void sig_c_handler(int sig) {
	if (cat_flag == -1) {
		setpgid(0, 0);
		cat_flag = 2;
	}
	pid_t imm_pid = fore_pid;
	bglist* mov = bg, * pre = bg;
	int flag = 0;
	for (mov = bg; mov != NULL; mov = mov->next)
		if (mov->pid == imm_pid) {
			strcpy(mov->status, "Done");
			flag = -1;
		}
	kill(imm_pid, SIGKILL);
}

void sig_z_handler(int signal) {
	if (cur_fg_flag != 0) {
		pid_t imm_pid = fore_pid;
		bglist* mov = bg, * pre = bg;
		for (mov = bg; mov != NULL; mov = mov->next) {
			if (mov->pid == imm_pid) {
				fgwait("", imm_pid);
				break;
			}
		}
		if (mov != NULL) {
			if (strcmp(mov->status, "Done")) {
				Kill(imm_pid, SIGTSTP);
			}
		}
		else {
			Kill(imm_pid, SIGTSTP);
		}
	}
}

void cmd_fg(char* number) {
	if (number[0] != '%') {
		printf("there is error input.\n");
		return;
	}
	char buf[MAXLINE];
	strcpy(buf, number);
	char n[10];
	pid_t re_pid = -1;
	n[0] = '\0';
	for (int i = 1; i < strlen(buf); i++)
		n[i - 1] = buf[i];
	bglist* mov = bg, * pre = bg;
	for (mov = bg; mov != NULL; mov = mov->next)
		if (mov->num == atoi(n) && !strcmp(mov->status, "Stopped")) {
			re_pid = mov->pid;
			strcpy(mov->status, "Running");
			break;
		}
	if (re_pid == -1) {
		printf("there is no stopped process!\n");
		return;
	}
	kill(re_pid, SIGCONT);
	cur_fg_flag = 1;
	while (1) {
		if(strcmp(mov->status, "Running"))
			break;
		sleep(1);
	}
	if (strcmp(mov->status, "Done") && strcmp(mov->status, "Terminated"))
		return;
	for (mov = bg; mov != NULL; mov = mov->next) {
		if (mov->pid == re_pid) {
			if (mov == bg) {
				pre = pre->next;
				bg = pre;
				free(mov);
				mov = pre;
				break;
			}
			else if (mov->next == NULL) {
				free(mov);
				pre->next = NULL;
				break;
			}
			else {
				pre->next = mov->next;
				free(mov);
				mov = pre->next;
				pre = mov;
				break;
			}
		}
	}
}

void cmd_bg(char* number) {
	if (number[0] != '%') {
		printf("there is error input.\n");
		return;
	}
	char buf[MAXLINE];
	strcpy(buf, number);
	char n[10];
	pid_t re_pid = -1;
	n[0] = '\0';
	for (int i = 1; i < strlen(buf); i++)
		n[i - 1] = buf[i];
	bglist* mov = bg, * pre = bg;
	for (mov = bg; mov != NULL; mov = mov->next) {
		if (mov->num == atoi(n) && !strcmp(mov->status, "Stopped")) {
			re_pid = mov->pid;
			strcpy(mov->status, "Running");
			mov->cmdline[strlen(mov->cmdline) - 1] = '\0';
			strcat(mov->cmdline, " &\n");
			printf("[%d]%c %s", mov->num, mov->operand, mov->cmdline);
		}
	}
	if (re_pid == -1) {
		printf("there is no stopped process!\n");
		return;
	}
	kill(re_pid, SIGCONT);
}

void cmd_kill(char* number) {
	if (number[0] != '%') {
		printf("there is error input.\n");
		return;
	}
	char buf[MAXLINE];
	strcpy(buf, number);
	char n[10];
	int i = 0;
	pid_t kill_pid = -1;
	for (i = 1; i < strlen(buf); i++)
		n[i - 1] = buf[i];
	n[i] = '\0';
	bglist* mov = bg, * pre = bg;
	for (mov = bg; mov != NULL; mov = mov->next) {
		if (mov->num == atoi(n)) {
			kill_pid = mov->pid;
			strcpy(mov->status, "Terminated");
			mov->cmdline[strlen(mov->cmdline) - 2] = '\n';
			mov->cmdline[strlen(mov->cmdline) - 1] = '\0';
		}
	}
	if (kill_pid == -1) {
		printf("there is no kill process!\n");
		return;
	}
	kill(kill_pid, SIGKILL);
}

void append_list(char* cmdline, int flag, pid_t pid) {
	bglist* new = (bglist*)malloc(sizeof(bglist));
	bglist* mov;
	new->num = ++bg_count;
	strcpy(new->cmdline, cmdline);
	if (flag == 0)
		strcpy(new->status, "Running");
	else if(flag == 1)
		strcpy(new->status, "Stopped");
	else
		strcpy(new->status, "Exit")
	new->operand = ' ';
	new->pid = pid;
	new->next = NULL;
	if (flag == 0)
		printf("[%d] %d\n", new->num, new->pid);
	else
		printf("\n[%d]%c\t%s\t\t\t%s", new->num, new->operand, new->status, new->cmdline);
	if (bg == NULL)
		bg = new;
	else {
		for (mov = bg; mov->next != NULL; mov = mov->next);
		mov->next = new;
	}
}

void print_done() {
	bglist* mov;
	for (mov = bg; mov != NULL; mov = mov->next) {
		if (!strcmp(mov->status, "Done") || !strcmp(mov->status, "Exit")) {
			mov->cmdline[strlen(mov->cmdline) - 1] = '\0';
			mov->cmdline[strlen(mov->cmdline) - 1] = '\n';
			printf("[%d]%c\t%d\t%s\t\t\t%s", mov->num, mov->operand, mov->pid, mov->status, mov->cmdline);
		}
		else if(!strcmp(mov->status, "Terminated"))
			printf("[%d]%c\t%d\t%s\t\t%s", mov->num, mov->operand, mov->pid, mov->status, mov->cmdline);
	}
}

void bglist_update() {
	bglist* mov;
	bglist* pre = bg;
	for (mov = bg; mov != NULL;) {
		if (!strcmp(mov->status, "Done") || !strcmp(mov->status, "Terminated") || !strcmp(mov->status, "Exit")) {
			if (mov == bg) { //1���� ����
				pre = pre->next;
				bg = pre;
				free(mov);
				mov = pre;
				if (bg == NULL) {
					break;
				}
				continue;
			}
			else if (mov->next == NULL) { //���� ������ bg�� ����
				free(mov);
				pre->next = NULL;
				break;
			}
			else { //�߰� bg�� ����
				pre->next = mov->next;
				free(mov);
				mov = pre->next;
				pre = mov;
				continue;
			}
		}
		pre = mov;
		mov = mov->next;
	}
}

void cmd_jobs(char** argv) {
	char cmd[MAXLINE];
	bglist* mov;
	if (argv[1] == NULL) {
		for (mov = bg; mov != NULL; mov = mov->next)
			if (strcmp(mov->status, "Done") && strcmp(mov->status, "Done"))
				printf("[%d]%c\t%d\t%s\t\t\t%s", mov->num, mov->operand, mov->pid, mov->status, mov->cmdline);
	}
}

/* If first arg is a builtin command, run it and return true */
int builtin_command(char** argv)
{
	if (!strcmp(argv[0], "quit") || !strcmp(argv[0], "exit")) /* quit command */
		exit(0);
	if (!strcmp(argv[0], "&"))    /* Ignore singleton & */
		return 1;
	if (!strcmp(argv[0], "cd")) {
		if (argv[1] == NULL)
			chdir(getenv("HOME"));
		else if (argv[1] != NULL) {
			if (chdir(argv[1]))
				printf("No directory.\n");
		}
		return 2;
	}
	if (!strcmp(argv[0], "jobs")) {
		cmd_jobs(argv);
		return 3;
	}
	if (!strcmp(argv[0], "fg")) {
		cmd_fg(argv[1]);
		return 4;
	}
	if (!strcmp(argv[0], "bg")) {
		cmd_bg(argv[1]);
		return 5;
	}
	if (!strcmp(argv[0], "kill")) {
		cmd_kill(argv[1]);
		return 6;
	}
	return 0;                     /* Not a builtin command */
}
/* $end eval */

/* $begin parseline */
/* parseline - Parse the command line and build the argv array */
int parseline(char* buf, char** argv)
{
	char* delim;         /* Points to first space delimiter */
	int argc;            /* Number of args */
	int bg;              /* Background job? */

	buf[strlen(buf) - 1] = ' ';  /* Replace trailing '\n' with space */
	while (*buf && (*buf == ' ')) /* Ignore leading spaces */
		buf++;

	/* Build the argv list */
	argc = 0;
	while ((delim = strchr(buf, ' '))) {
		argv[argc++] = buf;
		*delim = '\0';
		buf = delim + 1;
		while (*buf && (*buf == ' ')) /* Ignore spaces */
			buf++;
	}
	argv[argc] = NULL;

	if (argc == 0)  /* Ignore blank line */
		return 1;

	/* Should the job run in the background? */
	if ((bg = (*argv[argc - 1] == '&')) != 0)
		argv[--argc] = NULL;

	return bg;
}
/* $end parseline */


