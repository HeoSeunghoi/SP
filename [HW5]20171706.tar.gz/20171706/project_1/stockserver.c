/*
 * echoserveri.c - An iterative echo server
 */
 /* $begin echoserverimain */
#include "csapp.h"

typedef struct stock {
	int ID;
	int amount;
	int price;
	struct stock* left;
	struct stock* right;
}stock;

stock* data;
typedef struct { 
	int maxfd;
	fd_set read_set;
	fd_set ready_set;
	int nready;
	int maxi;
	int clientfd[MAXLINE];
	rio_t clientrio[MAXLINE];
} pool;

stock* read_stock();
void update_data(stock* data, FILE* fp);
void free_data(stock* tmp);
char* show(int connfd, stock* mov);
char* buy(int connfd, char* ID, char* amount, stock* tmp);
char* sell(int connfd, char* ID, char* amount, stock* tmp);
void init_pool(int listenfd, pool* p);
void add_client(int connfd, pool* p);
void check_clients(pool* p);

int byte_cnt = 0;
int main(int argc, char** argv)
{
	int listenfd;
	int connfd;
	socklen_t clientlen;
	struct sockaddr_storage clientaddr;  /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
	char client_hostname[MAXLINE], client_port[MAXLINE];
	static pool pool;
	if (argc != 2) {
		fprintf(stderr, "usage: %s <port>\n", argv[0]);
		exit(0);
	}

	listenfd = Open_listenfd(argv[1]);
	init_pool(listenfd, &pool);
	data = read_stock();
	while (1) {
		pool.ready_set = pool.read_set;
		pool.nready = Select(pool.maxfd + 1, &pool.ready_set, NULL, NULL, NULL);

		if (FD_ISSET(listenfd, &pool.ready_set)) {
			clientlen = sizeof(struct sockaddr_storage);
			connfd = Accept(listenfd, (SA*)&clientaddr, &clientlen);
			add_client(connfd, &pool);
		}
		check_clients(&pool);
	}
}
/* $end echoserverimain */

void init_pool(int listenfd, pool* p) {
	int i;
	p->maxi = -1;
	for (i = 0; i < MAXLINE; i++)
		p->clientfd[i] = -1;
	p->maxfd = listenfd;
	FD_ZERO(&p->read_set);
	FD_SET(listenfd, &p->read_set);
}

void add_client(int connfd, pool* p)
{
	int i;
	p->nready--;
	for (i = 0; i < MAXLINE; i++) /* Find an avai lable slot */
		if (p->clientfd[i] < 0) {
			p->clientfd[i] = connfd;
			Rio_readinitb(&p->clientrio[i], connfd);
			FD_SET(connfd, &p->read_set);
			if (connfd > p->maxfd)
				p->maxfd = connfd;
			if (i > p->maxi)
				p->maxi = i;
			break;
		}
	if (i == MAXLINE)
		app_error("add_client error : Too many clients");
}

void check_clients(pool* p) {
	int i, connfd, n;
	char buf[MAXLINE];
	char next[MAXLINE];
	char cmd[MAXLINE];
	char ID[MAXLINE];
	char amount[MAXLINE];
	char line[MAXLINE];
	int flag = 0;
	rio_t rio;

	for (i = 0; (i <= p->maxi) && (p->nready > 0); i++) {
		connfd = p->clientfd[i];
		rio = p->clientrio[i];
		if ((connfd > 0) && (FD_ISSET(connfd, &p->ready_set))) {
			p->nready--;
			if ((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0) {
				byte_cnt += n;
				printf("server received %d byte\n", n);
				strcpy(cmd, buf);
				cmd[strlen(cmd) - 1] = '\0';
				if (strchr(cmd, ' ') != NULL) {
					strcpy(cmd, strtok(cmd, " "));
					strcpy(next, strtok(NULL, ""));
				}
				if (strchr(next, ' ') != NULL) {
					strcpy(ID, strtok(next, " "));
					strcpy(next, strtok(NULL, " "));
				}
				if (strchr(next, ' ') != NULL) {
					strcpy(amount, strtok(NULL, ""));
				}
				else
					strcpy(amount, next);
				if (!strcmp(cmd, "show"))
					strcpy(line, show(connfd, data));
				else if (!strcmp(cmd, "buy"))
					strcpy(line, buy(connfd, ID, amount, data));
				else if (!strcmp(cmd, "sell"))
					strcpy(line, sell(connfd, ID, amount, data));
				else if (!strcmp(cmd, "exit"))
					strcpy(line, "exit");
				else
					flag = 1;

				if (flag == 0)
					Rio_writen(connfd, line, MAXLINE);
				else {
					Rio_writen(connfd, "", MAXLINE);
					flag = 0;
				}
				line[0] = '\0';
				cmd[0] = '\0';
			}
			else {
				Close(connfd);
				FD_CLR(connfd, &p->read_set);
				p->clientfd[i] = -1;
				FILE* fp = fopen("stock.txt", "w");
				update_data(data, fp);
				fclose(fp);
			}
		}
	}
}


char* show(int connfd, stock* tmp) {
	stock* mov;
	char line[MAXLINE];
	mov = tmp;
	if (mov == NULL)return "";
	sprintf(line, "%d %d %d\n", mov->ID, mov->amount, mov->price);
	strcat(line, show(connfd, mov->right));
	return strcat(line, show(connfd, mov->left));
}

char* sell(int connfd, char* ID, char* amount, stock* tmp) {
	if (ID == NULL || amount == NULL) {
		printf("Wrong input.\n");
		return "";
	}
	stock* mov;
	mov = tmp;
	while (mov != NULL) {
		if (mov->ID > atoi(ID))
			mov = mov->left;
		else if (mov->ID < atoi(ID))
			mov = mov->right;
		else {
			mov->amount += atoi(amount);
			break;
		}
	}
	return "[sell] success\n";
}

char* buy(int connfd, char* ID, char* amount, stock* tmp) {
	if (ID == NULL || amount == NULL) {
		printf("Wrong input.\n");
		return "";
	}
	stock* mov;
	mov = tmp;
	while (mov != NULL) {
		if (mov->ID > atoi(ID))
			mov = mov->left;
		else if (mov->ID < atoi(ID))
			mov = mov->right;
		else {
			if (mov->amount < atoi(amount)) {
				return "Not enough left stock\n"; // return
				break;
			}
			else {
				mov->amount -= atoi(amount);
				break;
			}
		}
	}
	return "[buy] success\n";
}


stock* read_stock() {
	FILE* fp = fopen("stock.txt", "r");
	stock* result = NULL;
	stock* new = NULL;
	stock* mov = NULL;
	char line[1024];
	char ID[MAXLINE];
	char amount[MAXLINE];
	char price[MAXLINE];
	int flag = 0;

	while (!feof(fp)) {
		flag = 0;
		fgets(line, 1024, fp);
		line[strlen(line) - 1] = '\0';
		if (line[0] == '\0') break;
		strcpy(ID, strtok(line, " "));
		strcpy(amount, strtok(NULL, " "));
		strcpy(price, strtok(NULL, ""));
		new = (stock*)malloc(sizeof(stock));
		new->ID = atoi(ID);
		new->amount = atoi(amount);
		new->price = atoi(price);
		new->left = NULL;
		new->right = NULL;
		if (result == NULL)
			result = new;
		else {
			mov = result;
			while (mov != NULL) {
				if (mov->ID > atoi(ID)) {
					if (mov->left != NULL)
						mov = mov->left;
					else {
						flag = -1;
						break;
					}
				}
				else if (mov->ID < atoi(ID)) {
					if (mov->right != NULL)
						mov = mov->right;
					else {
						flag = 1;
						break;
					}
				}
			}
			if (flag == 1)
				mov->right = new;
			else if (flag == -1)
				mov->left = new;
		}
	}
	fclose(fp);
	return result;
}

void update_data(stock* tmp, FILE* fp) {
	stock* mov = tmp;
	char line[100];
	if (mov == NULL)
		return;
	sprintf(line, "%d %d %d\n", mov->ID, mov->amount, mov->price);
	fputs(line, fp);
	update_data(mov->right, fp);
	update_data(mov->left, fp);
}

void free_data(stock* tmp) {
	if (tmp != NULL) {
		free_data(tmp->left);
		free_data(tmp->right);
		free(tmp);  // ��� ����
	}
}
