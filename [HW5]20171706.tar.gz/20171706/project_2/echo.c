/*
 * echo - read and echo text lines until client closes connection
 */
 /* $begin echo */
#include "csapp.h"

typedef struct stock {
	int ID;
	int amount;
	int price;
	int r_cnt;
	sem_t w;
	sem_t mutex;
	struct stock* left;
	struct stock* right;
}stock;

char* show(int connfd, stock* mov);
char* buy(int connfd, char* ID, char* amount, stock* tmp);
char* sell(int connfd, char* ID, char* amount, stock* tmp);

void echo(int connfd, stock* data)
{
	int n, flag = 0, flag1 = 0;
	char buf[MAXLINE];
	char next[MAXLINE];
	char cmd[MAXLINE];
	char ID[MAXLINE];
	char amount[MAXLINE];
	char line[MAXLINE];

	rio_t rio;
	Rio_readinitb(&rio, connfd);
	while ((n = Rio_readlineb(&rio, buf, MAXLINE)) != 0) {
		printf("server received %d bytes\n", n);
		if (flag == 0)
			flag = 1;
		else {
			Rio_readinitb(&rio, connfd);
		}
		strcpy(cmd, buf);
		cmd[strlen(cmd) - 1] = '\0';
		if (strchr(cmd, ' ') != NULL) {
			strcpy(cmd, strtok(cmd, " "));
			strcpy(next, strtok(NULL, ""));
		}
		if (strchr(next, ' ') != NULL) {
			strcpy(ID, strtok(next, " "));
			strcpy(next, strtok(NULL, " "));
		}
		if (strchr(next, ' ') != NULL) {
			strcpy(amount, strtok(NULL, ""));
		}
		else
			strcpy(amount, next);

		if (!strcmp(cmd, "show"))
			strcpy(line, show(connfd, data));
		else if (!strcmp(cmd, "buy"))
			strcpy(line, buy(connfd, ID, amount, data));
		else if (!strcmp(cmd, "sell"))
			strcpy(line, sell(connfd, ID, amount, data));
		else flag1 = 1;
		
		if(flag1 == 0)
			Rio_writen(connfd, line, MAXLINE);
		else {
			flag1 = 0;
			Rio_writen(connfd, line, MAXLINE);
		}
		line[0] = '\0';
	}
}
/* $end echo */

char* show(int connfd, stock* tmp) {
	stock* mov;
	char line[MAXLINE];
	mov = tmp;
	if (mov == NULL)return "";
	P(&mov->mutex);
	mov->r_cnt++;
	if (mov->r_cnt == 1)
		P(&mov->w);
	V(&mov->mutex);

	sprintf(line, "%d %d %d\n", mov->ID, mov->amount, mov->price);

	P(&mov->mutex);
	mov->r_cnt--;
	if (mov->r_cnt == 0)
		V(&mov->w);
	V(&mov->mutex);
	strcat(line, show(connfd, mov->right));
	return strcat(line, show(connfd, mov->left));
}

char* sell(int connfd, char* ID, char* amount, stock* tmp) {
	if (ID == NULL || amount == NULL) {
		printf("Wrong input.\n");
		return "";
	}
	stock* mov;
	mov = tmp;
	while (mov != NULL) {
		if (mov->ID > atoi(ID))
			mov = mov->left;
		else if (mov->ID < atoi(ID))
			mov = mov->right;
		else {
			P(&mov->w);
			mov->amount += atoi(amount);
			V(&mov->w);
			break;
		}
	}
	return "[sell] success\n";
}

char* buy(int connfd, char* ID, char* amount, stock* tmp) {
	if (ID == NULL || amount == NULL) {
		printf("Wrong input.\n");
		return "";
	}
	stock* mov;
	mov = tmp;
	while (mov != NULL) {
		if (mov->ID > atoi(ID))
			mov = mov->left;
		else if (mov->ID < atoi(ID))
			mov = mov->right;
		else {
			P(&mov->w);
			if (mov->amount < atoi(amount)) {
				V(&mov->w);
				return "Not enough left stock\n"; // return
			}
			else {
				mov->amount -= atoi(amount);
				V(&mov->w);
				break;
			}
		}
	}
	return "[buy] success\n";
}
