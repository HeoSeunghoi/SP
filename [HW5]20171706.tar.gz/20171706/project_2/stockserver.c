/*
 * echoserveri.c - An iterative echo server
 */
 /* $begin echoserverimain */
#include "csapp.h"

typedef struct stock {
	int ID;
	int amount;
	int price;
	int r_cnt;
	sem_t w;
	sem_t mutex;
	struct stock* left;
	struct stock* right;
}stock;

stock* data;

void echo(int connfd, stock* data);
stock* read_stock();
void update_data(stock* data, FILE* fp);
void free_data(stock* tmp);
void* thread(void* vargp);

int main(int argc, char** argv)
{
	int listenfd;
	int connfd;
	pthread_t tid;
	socklen_t clientlen;
	struct sockaddr_storage clientaddr;  /* Enough space for any address */  //line:netp:echoserveri:sockaddrstorage
	char client_hostname[MAXLINE], client_port[MAXLINE];

	if (argc != 2) {
		fprintf(stderr, "usage: %s <port>\n", argv[0]);
		exit(0);
	}

	listenfd = Open_listenfd(argv[1]);
	data = read_stock();
	while (1) {
		clientlen = sizeof(struct sockaddr_storage);
		connfd = Accept(listenfd, (SA*)&clientaddr, &clientlen);
		Getnameinfo((SA*)&clientaddr, clientlen, client_hostname, MAXLINE,
			client_port, MAXLINE, 0);
		Pthread_create(&tid, NULL, thread, (void*)connfd);
		printf("Connected to (%s, %s)\n", client_hostname, client_port);
		//Pthread
	}
	exit(0);
}
/* $end echoserverimain */
void* thread(void* vargp) {
	int myid = (long)vargp;
	echo(myid, data);
	FILE* fp = fopen("stock.txt", "w");
	update_data(data, fp);
	fclose(fp);
}

stock* read_stock() {
	FILE* fp = fopen("stock.txt", "r");
	stock* result = NULL;
	stock* new = NULL;
	stock* mov = NULL;
	char line[1024];
	char ID[MAXLINE];
	char amount[MAXLINE];
	char price[MAXLINE];
	int flag = 0;

	while (!feof(fp)) {
		flag = 0;
		fgets(line, 1024, fp);
		line[strlen(line) - 1] = '\0';
		if (line[0] == '\0') break;
		strcpy(ID, strtok(line, " "));
		strcpy(amount, strtok(NULL, " "));
		strcpy(price, strtok(NULL, ""));
		new = (stock*)malloc(sizeof(stock));
		new->ID = atoi(ID);
		new->amount = atoi(amount);
		new->price = atoi(price);
		Sem_init(&new->mutex, 0, 1);
		Sem_init(&new->w, 0, 1);
		new->r_cnt = 0;
		new->left = NULL;
		new->right = NULL;
		if (result == NULL)
			result = new;
		else {
			mov = result;
			while (mov != NULL) {
				if (mov->ID > atoi(ID)) {
					if (mov->left != NULL)
						mov = mov->left;
					else {
						flag = -1;
						break;
					}
				}
				else if (mov->ID < atoi(ID)) {
					if (mov->right != NULL)
						mov = mov->right;
					else {
						flag = 1;
						break;
					}
				}
			}
			if (flag == 1)
				mov->right = new;
			else if (flag == -1)
				mov->left = new;
		}
	}
	fclose(fp);
	return result;
}

void update_data(stock* tmp, FILE* fp) { // mutex �߰��� �� ��
	stock* mov = tmp;
	char line[100];
	if (mov == NULL)
		return;
	P(&mov->mutex);
	mov->r_cnt++;
	if (mov->r_cnt == 1)
		P(&mov->w);
	V(&mov->mutex);

	sprintf(line, "%d %d %d\n", mov->ID, mov->amount, mov->price);

	P(&mov->mutex);
	mov->r_cnt--;
	if (mov->r_cnt == 0)
		V(&mov->w);
	V(&mov->mutex);
	fputs(line, fp);
	update_data(mov->right, fp);
	update_data(mov->left, fp);
}

void free_data(stock* tmp) {
	if (tmp != NULL) {
		free_data(tmp->left);
		free_data(tmp->right);
		free(tmp);  // ��� ����
	}
}