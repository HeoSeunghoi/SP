#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <ctype.h>
#include<math.h>
//#include<dirent.h>
//#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include "20171706.h"

int main() {
    opcode = (oplist**)malloc(sizeof(oplist*) * 20);
    for (int i = 0; i < 20; i++) { //Allocate virtual memory space
        opcode[i] = (oplist*)malloc(sizeof(oplist));
        opcode[i] = NULL;
    }
    readOpcode();
    if (flag == -1) //If the opcode.txt does not exist, the program is terminated.
        exit(1);

    char* str = (char*)malloc(sizeof(char) * 100); //String space for command input
    char str_check[100]; //Generated to check if the command is correct
    char check[100]; //Generated to check if the command is correct
    char check2[100]; //Generated to check if the command is correct
    char strSave[100]; //Space to store refined results when correct input comes in
    int trash; //Space to store unused return values
    oplist* check_M; //Space to check if memory space is low
    hist = NULL;
    printf("sicsim>");
    trash = scanf("%[^\n]s", str);
    while (1) { //If nothing is entered, repeat until the correct input is received
        if (str[0] == -51) {
            printf("Retry.\nsicsim>");
            trash = getchar();
            trash = scanf("%[^\n]s", str);
        }
        else
            break;
    }
    //Copy to str_check after removing left and right spaces of str
    str = DeleteleftSpace(str);
    str = DeleterightSpace(str);
    strcpy(str_check, str);
    reset();
    //Run the appropriate function using str_check.
    while (1) {
        if (strcmp(str_check, "quit") == 0 || strcmp(str_check, "q") == 0)
            break;
        else if (strcmp(str_check, "help") == 0 || strcmp(str_check, "h") == 0) {
            printf("h[elp]\nd[ir]\nq[uit]\nhi[story]\ndu[mp] [start, end]\ne[dit] address, value\nf[ill] start, end, value\nreset\nopcode mnemonic\nopcodelist\n");
            if (flag == 0) //If correct input, save in hist
                saveHi(str);
        }
        else if (strcmp(str_check, "dir") == 0 || strcmp(str_check, "d") == 0) {
            dir();
            if (flag == 0) //If correct input, save in hist
                saveHi(str);
        }
        else if (strcmp(str_check, "history") == 0 || strcmp(str_check, "hi") == 0) {
            saveHi(str);
            history();
        }
        else if (strcmp(str_check, "dump") == 0 || strcmp(str_check, "du") == 0) {
            strcpy(strSave, dump(str)); //Copy the refined string resulting from the dump function to strSave
            if (flag == 0) //If correct input, save in hist
                saveHi(strSave);
        }
        else if (strcmp(str, "reset") == 0) {
            reset();
            if (flag == 0) //If correct input, save in hist
                saveHi(str);
        }
        else if (strcmp(strtok(str_check, " "), "edit") == 0 || strcmp(strtok(str_check, " "), "e") == 0 || strcmp(strtok(str_check, "\t"), "edit") == 0 || strcmp(strtok(str_check, "\t"), "e") == 0) {
            strcpy(strSave, edit(str)); //Copy the refined string resulting from the edit function to strSave
            if (flag == 0) //If correct input, save in hist
                saveHi(strSave);
        }
        else if (strcmp(strtok(str_check, " "), "fill") == 0 || strcmp(strtok(str_check, " "), "f") == 0 || strcmp(strtok(str_check, "\t"), "fill") == 0 || strcmp(strtok(str_check, "\t"), "f") == 0) {
            strcpy(strSave, fill(str)); //Copy the refined string resulting from the fill function to strSave
            if (flag == 0) //If correct input, save in hist
                saveHi(strSave);
        }
        else if (strcmp(strtok(str_check, " "), "opcode") == 0 || strcmp(strtok(str_check, "\t"), "opcode") == 0) {
            strcpy(strSave, mnemonic(str)); //Copy the refined string resulting from the mnemonic function to strSave
            if (flag == 0) //If correct input, save in hist
                saveHi(strSave);
        }
        else if (strcmp(str_check, "opcodelist") == 0) {
            opcodeList();
            saveHi(str);
        }
        else {
            //Copy from str to check and check1 for a certain length.
            strncpy(check, str, 3);
            strncpy(check2, str, 5);
            check[3] = '\0';
            check2[5] = '\0';

            //Execute the appropriate function if conditions are met
            if (strcmp(check, "du ") == 0 || strcmp(check2, "dump ") == 0) {
                strcpy(strSave, dump(str)); //Copy the refined string resulting from the dump function to strSave
                if (flag == 0)
                    saveHi(strSave);
            }
            else if (strcmp(check, "du\t") == 0 || strcmp(check2, "dump\t") == 0) {
                strcpy(strSave, dump(str));
                if (flag == 0)
                    saveHi(strSave);
            }
            else //In case of wrong input
                printf("Wrong.\n");
        }
        //If str is input again
        printf("sicsim>");
        strcpy(str, "@");
        trash = getchar();
        trash = scanf("%[^\n]s", str);
        while (strcmp(str, "@") == 0) { //If nothing is entered in str, repeat until input is entered
            printf("Retry.\nsicsim>");
            trash = getchar();
            trash = scanf("%[^\n]s", str);
        }
        //Copy to str_check after removing left and right spaces of str
        str = DeleteleftSpace(str);
        str = DeleterightSpace(str);
        strcpy(str_check, str);
        flag = 0;

        //Check if there is free space in memory
        if ((check_M = (oplist*)malloc(sizeof(oplist))) == NULL) {
            fprintf(stderr, "Insufficient memory");
            exit(EXIT_FAILURE);
        }
        free(check_M);
    }
    //Free all dynamically allocated space before terminating the program
    freeList();
    freeHi();
    free(str);
    flag = trash;
    return 0;
}

void history() {
    int i = 1;
    for (list* print = hist; print != NULL; print = print->next)
        printf("%d\t%s\n", i++, print->hi);
}

void saveHi(char str[]) {
    if (hist == NULL) { //Create space and save data when heist is empty
        hist = (list*)malloc(sizeof(list));
        strcpy(hist->hi, str);
        hist->next = NULL;
    }
    else { //Create a new space tmp if not empty and connect to the correct location
        list* tmp = (list*)malloc(sizeof(list));
        list* mov = hist;
        strcpy(tmp->hi, str);
        tmp->next = NULL;
        for (; mov->next != NULL; mov = mov->next);
        mov->next = tmp;
    }
}

char* dump(char str[]) {
    int i, j, x = adrs / 16;
    int adrss = 0; // variable to store temporary address value when inputted in the form of dump A or dump A or B
    char* a = NULL, * b = NULL; // space for splitting the entered str and storing only the required string
    char check1[100]; // variables to store du and du\t
    char check2[100];// variables to store dump and dump\t
    char* str2 = NULL; //str, space to store non-dump strings when you jog
    int A, B; //variable to store address values
    static char strSave[100]; //space to store refined results
    strSave[0] = '\0';

    if (strcmp(str, "dump") == 0 || strcmp(str, "du") == 0) {
        for (i = x; i < x + 10; i++) {
            //output addresses for virtual memory space
            printf("%05X", adrs);
            adrs += 16;
            //Reset adrs to zero if outside the range of the address
            if (adrs > 1048575)
                adrs = 0;

            for (j = 0; j < 16; j++) { //Outputs data stored in the virtual notepad space in hexadecimal form
                printf(" %02X", shell[i][j]);
            }
            printf(" ;");
            for (j = 0; j < 16; j++) { //Output ASCII code values for data stored in virtual memory space
                if (shell[i][j] < 32 || shell[i][j]>126)
                    printf(".");
                else
                    printf("%c", shell[i][j]);
            }
            printf("\n");
        }
    }
    else { //In case of input in the form of dump A or dump A or B
        strncpy(check1, str, 3);
        check1[3] = '\0';
        strncpy(check2, str, 5);
        check2[5] = '\0';
        if (strcmp(check1, "du ") == 0 || strcmp(check2, "dump ") == 0) {
            //Store dump in str2 and remove left and right spaces in str2
            str = strtok(str, " ");
            str2 = strtok(NULL, "");
            strcpy(str2, DeleterightSpace(str2));
            strcpy(str2, DeleteleftSpace(str2));

            if (str_chr(str2, ',') == 0) { //In case input is made in the form of dump A
                for (i = 0; i < (int)strlen(str2); i++) { //Verify A is Hex
                    A = str2[i];
                    if (isxdigit(A) == 0) {
                        printf("Wrong.\n");
                        flag = -1;
                        return " ";
                    }
                }
                //Ensure that A is in the address range
                A = strtol(str2, NULL, 16);
                if (range(A) == -1) {
                    printf("Over range.\n");
                    flag = -1;
                    return " ";
                }
                //Save temporary address to adrss
                adrss = strtol(str2, NULL, 16);
                adrss = (adrss / 16) * 16;
                for (i = A / 16; i <= A / 16 + 10; i++) { //Output according to output format
                    if (i == A / 16 + 10 && A % 16 == 0) //In case the last digit of A is 0 and all 160 are printed
                        break;
                    //Output memory address
                    if (adrss > 1048575)
                        break;
                    printf("%05X", adrss);
                    adrss += 16;

                    //Outputs only values between the start and end addresses of the addresses
                    if (i == A / 16) {
                        for (j = 0; j < A % 16; j++) {
                            printf("   ");
                        }
                        for (; j < 16; j++) {
                            printf(" %02X", shell[i][j]);
                        }
                    }
                    else if (i == A / 16 + 10) {
                        for (j = 0; j < A % 16; j++) {
                            printf(" %02X", shell[i][j]);
                        }
                        for (; j < 16; j++) {
                            printf("   ");
                        }
                    }
                    else {
                        for (j = 0; j < 16; j++) {
                            printf(" %02X", shell[i][j]);
                        }
                    }
                    
                    printf(" ;");
                    for (j = 0; j < 16; j++) { //Outputs the rest of the input as "." except for the data value of the address range and the value of the output range of the ASCII code
                        if (j < A % 16)
                            printf(".");
                        else if (shell[i][j] < 32 || shell[i][j]>126)
                            printf(".");
                        else
                            printf("%c", shell[i][j]);
                    }
                    printf("\n");
                }
                //Returns a refined string
                strcat(strSave, str);
                strcat(strSave, " ");
                strcat(strSave, str2);
                return strSave;
            }
        }
        else if (strcmp(check1, "du\t") == 0 || strcmp(check2, "dump\t") == 0) {//dump\tA���·� �Է¹޴� ���
            //Operate in the same form as dump A
            str = strtok(str, "\t");
            str2 = strtok(NULL, "");

            strcpy(str2, DeleterightSpace(str2));
            strcpy(str2, DeleteleftSpace(str2));

            if (str_chr(str2, ',') == 0) {
                for (i = 0; i < (int)strlen(str2); i++) {
                    A = str2[i];
                    if (isxdigit(A) == 0) {
                        printf("Wrong.\n");
                        flag = -1;
                        return " ";
                    }
                }
                A = strtol(str2, NULL, 16);
                if (range(A) == -1) {
                    printf("Over range.\n");
                    flag = -1;
                    return " ";
                }

                adrss = strtol(str2, NULL, 16);
                adrss = (adrss / 16) * 16;
                for (i = A / 16; i <= A / 16 + 10; i++) {

                    if (i == A / 16 + 10 && A % 16 == 0)
                        break;
                    if (adrss > 1048575)
                        break;
                    printf("%05X", adrss);
                    adrss += 16;

                    if (i == A / 16) {
                        for (j = 0; j < A % 16; j++) {
                            printf("   ");
                        }
                        for (; j < 16; j++) {
                            printf(" %02X", shell[i][j]);
                        }
                    }
                    else if (i == A / 16 + 10) {
                        for (j = 0; j < A % 16; j++) {
                            printf(" %02X", shell[i][j]);
                        }
                        for (; j < 16; j++) {
                            printf("   ");
                        }
                    }
                    else {
                        for (j = 0; j < 16; j++) {
                            printf(" %02X", shell[i][j]);
                        }
                    }

                    printf(" ;");
                    for (j = 0; j < 16; j++) {
                        if (j < A % 16)
                            printf(".");
                        else if (shell[i][j] < 32 || shell[i][j]>126)
                            printf(".");
                        else
                            printf("%c", shell[i][j]);
                    }
                    printf("\n");
                }
                strcat(strSave, str);
                strcat(strSave, " ");
                strcat(strSave, str2);
                return strSave;
            }
        }
        else if (str_chr(str2, ',') != 1) { //"," recognized as invalid input if there are more than two "," processed above if there are zero.
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
        //Store the starting and ending addresses of the outputs in a and b
        a = strtok(str2, ",");
        b = strtok(NULL, "");

        //Make sure a and b are NULL and remove left and right spaces if not NULL
        if (a != NULL) {
            strcpy(a, DeleterightSpace(a));
            strcpy(a, DeleteleftSpace(a));
        }
        else {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
        if (b != NULL) {
            strcpy(b, DeleterightSpace(b));
            strcpy(b, DeleteleftSpace(b));
        }
        else {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }

        if (a == NULL) {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
        //Terminate a function unless a and b are hexadecimal
        for (i = 0; i < (int)strlen(a); i++) {
            A = a[i];
            if (isxdigit(A) == 0) {
                printf("Wrong.\n");
                flag = -1;
                return " ";
            }
        }
        for (i = 0; i < (int)strlen(b); i++) {
            B = b[i];
            if (isxdigit(B) == 0) {
                printf("Wrong.\n");
                flag = -1;
                return " ";
            }
        }

        //Ensure that a and b are in the correct range
        A = strtol(a, NULL, 16);
        if (range(A) == -1) {
            printf("Over range.\n");
            flag = -1;
            return " ";
        }
        B = strtol(b, NULL, 16);
        if (range(B) == -1) {
            printf("Over range.\n");
            flag = -1;
            return " ";
        }

        if (A > B) { //If A is greater than B, treat as invalid input
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
        //Save address value to start output
        adrss = strtol(str2, NULL, 16);
        adrss = (adrss / 16) * 16;

        for (i = A / 16; i <= B / 16; i++) { //Output data between start and end ranges to the output format

            printf("%05X", adrss);
            adrss += 16;

            if (i == A / 16) {
                for (j = 0; j < A % 16; j++) {
                    printf("   ");
                }
                if (i != B / 16) {
                    for (; j < 16; j++) {
                        printf(" %02X", shell[i][j]);
                    }
                }
                else {
                    for (; j <= B % 16; j++) {
                        printf(" %02X", shell[i][j]);
                    }
                    for (; j < 16; j++) {
                        printf("   ");
                    }
                }

            }
            else if (i != B / 16) {
                for (j = 0; j < 16; j++) {
                    printf(" %02X", shell[i][j]);
                }
            }
            else if (i == B / 16) {
                for (j = 0; j <= B % 16; j++) {
                    printf(" %02X", shell[i][j]);
                }
                for (; j < 16; j++) {
                    printf("   ");
                }
            }
            printf(" ;");
            for (j = 0; j < 16; j++) {
                if (j < A % 16 || j>B % 16)
                    printf(".");
                else if (shell[i][j] < 32 || shell[i][j]>126)
                    printf(".");
                else
                    printf("%c", shell[i][j]);
            }
            printf("\n");
        }
    }
    //Returns a refined string
    strcat(strSave, str);
    if (a != NULL) {
        strcat(strSave, " ");
        strcat(strSave, a);
    }
    if (b != NULL) {
        strcat(strSave, ", ");
        strcat(strSave, b);
    }
    return strSave;
}

char* DeleterightSpace(char* s)
{
    char* line = NULL;
    line = (char*)malloc(sizeof(char) * 100);
    char* end;

    strcpy(line, s);
    end = line + strlen(line) - 1;
    while (end != line && isspace(*end))
        end--;
    *(end + 1) = '\0';
    strcpy(s, line);
    free(line);
    return s;
}

char* DeleteleftSpace(char* s) {
    char* str;
    str = s;
    while (*str != '\0') {
        if (isspace(*str))
            str++;
        else {
            s = str;
            break;
        }
    }
    return s;
}

int str_chr(char* s, char c) {
    int i;
    int count = 0;
    for (i = 0; i < (int)strlen(s); i++) {
        if (s[i] == c)
            count++;
    }
    return count;
}

char* edit(char* str) {
    int i, j, A = 0, B = 0;
    char* str2 = str;
    char* a = NULL;
    char* b = NULL;
    char check1[100];
    char check2[100];
    static char strSave[100];
    strSave[0] = '\0';

    //Copy str to check1 and check2 for a certain length and verify that it is the correct input
    strncpy(check1, str, 2);
    check1[2] = '\0';
    strncpy(check2, str, 5);
    check2[5] = '\0';

    //Split str according to each standard and remove left and right spaces of str2
    if (strcmp(check1, "e ") == 0 || strcmp(check2, "edit ") == 0) { //The string starts with e or edit.
        str = strtok(str, " ");
        str2 = strtok(NULL, "");
    }
    else if (strcmp(check1, "e\t") == 0 || strcmp(check2, "edit\t") == 0) { //e\tȤ�� edit\t�� ���ڿ��� ���۵Ǵ� ���
        str = strtok(str, "\t");
        str2 = strtok(NULL, "");
    }
    strcpy(str2, DeleterightSpace(str2));
    strcpy(str2, DeleteleftSpace(str2));


    if (str_chr(str2, ',') != 1) { //str2�� ','�� 1���� �ƴ� ��� �߸��� �Է����� ó��
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    //Store address values and data values in a and b if the input is correct
    a = strtok(str2, ",");
    b = strtok(NULL, "");
    //If a and b are not NULL, remove left and right spaces
    if (a != NULL) {
        strcpy(a, DeleterightSpace(a));
        strcpy(a, DeleteleftSpace(a));
    }
    else {
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    if (b != NULL) {
        strcpy(b, DeleterightSpace(b));
        strcpy(b, DeleteleftSpace(b));
    }
    else {
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    //Verify that a and b are hexadecimal
    for (i = 0; i < (int)strlen(a); i++) {
        A = a[i];
        if (isxdigit(A) == 0) {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
    }
    for (i = 0; i < (int)strlen(b); i++) {
        B = b[i];
        if (isxdigit(B) == 0) {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
    }
    //Verify that a is the address value range and that b is included in the data value range.
    A = strtol(a, NULL, 16);
    if (range(A) == -1) {
        printf("Over range.\n");
        flag = -1;
        return " ";
    }
    B = strtol(b, NULL, 16);
    if (rangeV(B) == -1) {
        printf("Over range.\n");
        flag = -1;
        return " ";
    }
    //Store the correct shell location in i and j
    i = A / 16;
    j = A % 16;
    shell[i][j] = B;

    //Returns a refined string
    strcat(strSave, str);
    if (a != NULL) {
        strcat(strSave, " ");
        strcat(strSave, a);
    }
    if (b != NULL) {
        strcat(strSave, ", ");
        strcat(strSave, b);
    }
    return strSave;
}

char* fill(char* str) {
    int i, j, A = 0, B = 0, C = 0;
    char* str2 = NULL;
    char* a = NULL;
    char* b = NULL;
    char* c = NULL;
    char check1[100];
    char check2[100];
    static char strSave[100];
    strSave[0] = '\0';

    strncpy(check1, str, 2);
    check1[2] = '\0';
    strncpy(check2, str, 5);
    check2[5] = '\0';
    //Split str according to each standard and remove left and right spaces of str2
    if (strcmp(check1, "f ") == 0 || strcmp(check2, "fill ") == 0) {
        str = strtok(str, " ");
        str2 = strtok(NULL, "");
    }
    else if (strcmp(check1, "f\t") == 0 || strcmp(check2, "fill\t") == 0) {
        str = strtok(str, "\t");
        str2 = strtok(NULL, "");
    }
    if (str2 != NULL) {
        strcpy(str2, DeleterightSpace(str2));
        strcpy(str2, DeleteleftSpace(str2));
    }

    if (str2 == NULL) {
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    if (str_chr(str2, ',') != 2) {//If the number of ',' contained in str2 is not 2, it is recognized as an invalid input
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    //Start, end, and store data values in a, b, and c
    a = strtok(str2, ",");
    b = strtok(NULL, ",");
    c = strtok(NULL, "");

    //Check if a, b, and c are NULL and remove left and right spaces if not
    if (a != NULL) {
        strcpy(a, DeleterightSpace(a));
        strcpy(a, DeleteleftSpace(a));
    }
    else {
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    if (b != NULL) {
        strcpy(b, DeleterightSpace(b));
        strcpy(b, DeleteleftSpace(b));
    }
    else {
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    if (c != NULL) {
        strcpy(c, DeleterightSpace(c));
        strcpy(c, DeleteleftSpace(c));
    }
    else {
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }

    //Check if a, b, and c are hexadecimal
    for (i = 0; i < (int)strlen(a); i++) {
        A = a[i];
        if (isxdigit(A) == 0) {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
    }
    for (i = 0; i < (int)strlen(b); i++) {
        B = b[i];
        if (isxdigit(B) == 0) {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
    }
    for (i = 0; i < (int)strlen(c); i++) {
        C = c[i];
        if (isxdigit(C) == 0) {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
    }
    //Ensure that a, b, and c are in the correct range
    A = strtol(a, NULL, 16);
    B = strtol(b, NULL, 16);
    C = strtol(c, NULL, 16);
    if (range(A) == -1 || range(B) == -1 || rangeV(C) == -1) {
        printf("Over range.\n");
        flag = -1;
        return " ";
    }
    
    if (A > B) {//If the start address is smaller than the end address, treat it as an invalid input
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }

    //Change the data value between a and b to c
    for (i = A / 16; i <= B / 16; i++) {
        if (i == A / 16) {
            if (A / 16 == B / 16) {
                for (j = A % 16; j <= B % 16; j++) {
                    shell[i][j] = C;
                }
            }
            else {
                for (j = A % 16; j < 16; j++) {
                    shell[i][j] = C;
                }
            }
        }
        else {
            if (i == B / 16) {
                for (j = 0; j <= B % 16; j++) {
                    shell[i][j] = C;
                }
            }
            else {
                for (j = 0; j < 16; j++) {
                    shell[i][j] = C;
                }
            }
        }
    }
    //Returns a refined string
    strcat(strSave, str);
    if (a != NULL) {
        strcat(strSave, " ");
        strcat(strSave, a);
    }
    if (b != NULL) {
        strcat(strSave, ", ");
        strcat(strSave, b);
    }
    if (c != NULL) {
        strcat(strSave, ", ");
        strcat(strSave, c);
    }
    return strSave;
}

void dir() {
    /*int count = 0;
    struct stat buf;
    DIR* dir = NULL;
    struct dirent* entry = NULL;

    dir = opendir(".");
    if (dir == NULL) {
        printf("current directory error\n");
        exit(1);
    }
    while ((entry = readdir(dir)) != NULL) {
        lstat(entry->d_name, &buf);
        if (count < 3) { //If you haven't printed four yet
            if (S_ISDIR(buf.st_mode)) //directory
                printf("%15s/", entry->d_name);
            else if (S_IEXEC & buf.st_mode) //Executable file
                printf("%15s*", entry->d_name);
            else { //the rest of the case
                printf("%15s", entry->d_name);
            }
            count++;
        }
        else { //If the fourth output is output
            if (S_ISDIR(buf.st_mode))
                printf("%15s/\n", entry->d_name);
            else if (S_IEXEC & buf.st_mode)
                printf("%15s*\n", entry->d_name);
            else {
                printf("%15s\n", entry->d_name);
            }
            count = 0;
        }
    }
    printf("\n");
    closedir(dir);*/
}

void reset() {
    for (int i = 0; i < 65536; i++)
        for (int j = 0; j < 16; j++)
            shell[i][j] = 0;
}

void readOpcode() {
    //Verify that the opcode.txt file exists
    FILE* fp = fopen("opcode.txt", "r");
    if (fp == NULL) {
        printf("There is no file.\n");
        flag = -1;
        return;
    }
    int i = 0;
    int Code = 0;
    int trash;
    char name[100];
    char num[100];
    char code[100];
    oplist* mov;
    //Read the data stored in opcode.txt one line to the end of the file and save the data to the oplist
    trash = fscanf(fp, "%s %s %s", code, name, num);
    while (!feof(fp)) {
        //Store read data in mk
        oplist* mk = (oplist*)malloc(sizeof(oplist));
        Code = strtol(code, NULL, 16);
        mk->code = Code;
        strcpy(mk->name, name);
        strcpy(mk->num, num);
        mk->next = NULL;

        if (opcode[i] == NULL && i < 20) //if i is less than 20 and opcode[i] is NULL
            opcode[i++] = mk;
        else if (i < 20) { //i�� 20���� ���� ���
            mov = opcode[i];
            while (mov->next != NULL) {//Save data at the end of opcode[i]
                mov = mov->next;
            }
            mov->next = mk;
            i++;
        }
        else { //If i is 20, initialize i to zero and save data at the end of opcode [i]
            i = 0;
            mov = opcode[i++];
            while (mov->next != NULL) {
                mov = mov->next;
            }
            mov->next = mk;
        }

        trash = fscanf(fp, "%s %s %s", code, name, num);
    }
    Code = trash;
    fclose(fp);
}

char* mnemonic(char* str) {
    int i;
    char* name = NULL;
    static char strSave[100];
    strSave[0] = '\0';
    char check[100] = { '\0' };
    oplist* mov;
    //Distinguish between "opcode" and "opcode\t" and divide them into names and str.
    strncpy(check, str, 7);
    if (strcmp(check, "opcode ") == 0) {
        str = strtok(str, " ");
        name = strtok(NULL, "");
    }
    else if (strcmp(check, "opcode\t") == 0) {
        str = strtok(str, "\t");
        name = strtok(NULL, "");
    }
    //Verify name is NULL and remove left and right spaces
    if (name == NULL) {
        printf("Wrong\n");
        flag = -1;
        return " ";
    }
    else {
        strcpy(name, DeleterightSpace(name));
        strcpy(name, DeleteleftSpace(name));
    }

    for (i = 0; i < 20; i++) { //Compare name to data stored in opcode and output according to output type if it matches the name
        mov = opcode[i];
        while (mov != NULL) {
            if (strcmp(name, mov->name) == 0) {
                printf("opcode is %02X\n", mov->code);
                break;
            }

            mov = mov->next;
        }
        if (mov != NULL)
            break;
    }
    if (i == 20) {//Treat as invalid input if not in the list
        flag = -1;
        printf("Wrong.\n");
        return " ";
    }
    //Returns a refined string
    strcat(strSave, str);
    if (name != NULL) {
        strcat(strSave, " ");
        strcat(strSave, name);
    }
    return strSave;
}

void opcodeList() {
    int i;
    oplist* mov;

    for (i = 0; i < 20; i++) {
        mov = opcode[i];
        printf("%d :", i);
        while (mov->next != NULL) {
            printf(" [%s,%02X] -> ", mov->name, mov->code);
            mov = mov->next;
        }
        printf("[%s,%02X]\n", mov->name, mov->code);
    }
}

int range(int x) {
    if (x < 0 || x>1048575)
        return -1;
    else return 0;
}

int rangeV(int x) {
    if (x < 0 || x>255)
        return -1;
    else return 0;
}

void freeList() {
    oplist* mov;
    for (int i = 0; i < 20; i++) {
        mov = opcode[i];
        if (mov == NULL)
            continue;
        while (opcode[i] != NULL) {
            mov = opcode[i];
            opcode[i] = opcode[i]->next;
            free(mov);
        }
    }
}

void freeHi() {
    list* mov;
    mov = hist;

    if (mov == NULL)
        return;
    while (hist != NULL) {
        mov = hist;
        hist = hist->next;
        free(mov);
    }
}