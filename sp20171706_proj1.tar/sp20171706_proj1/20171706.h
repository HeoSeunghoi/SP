﻿#ifndef __20171706_H__
#define __20171706_H__

typedef struct list { //Structure format to store in the form of a linked list in history
    char hi[100];
    struct list* next;
}list;

typedef struct oplist { //Structure format for storing opcodes in Has table format
    char name[100];
    unsigned char code;
    char num[100];
    struct oplist* next;
}oplist;

list* hist; //Global variable to save in linek list format
unsigned char shell[65536][16]; //Virtual memory space(1MB)
oplist** opcode; //Global variable to create a hash table
int adrs = 0; //Save current address to access virtual memory space
int flag = 0; //Variable that determines whether to save in history when input is received

void history(); //Function to print data stored in hist
void saveHi(char str[]); //A function that stores the refined result in hist when the correct input is received.
char* dump(char str[]); //Function that outputs the correct input value according to the output format
void dir(); //A function that outputs the file in the current directory according to the format when the correct input is received.
void reset(); //A function that initializes all values of the virtual memory shell to 0
char* DeleterightSpace(char* s); //A function that removes all spaces from the right of a string
char* DeleteleftSpace(char* s); //A function that removes all spaces from the left of a string
int str_chr(char* s, char c); //Function that prints the number of specific characters in a string
char* edit(char* str); //A function that changes the data of a specific location in the virtual memory space when the correct input is received.
char* fill(char* str); //Function that changes all data in the corresponding range of virtual memory space when the correct input is received
void readOpcode(); // A function that reads the opcode.txt file and saves the data in the oplist
char* mnemonic(char* str); //Function that outputs the code of specific data stored in the oplist when the correct input is received
void opcodeList(); //A function that outputs all data values stored in the oplist according to the format
int range(int x); // A function that checks whether the value of int x is within the range of address
int rangeV(int x); //A function that checks whether the value of int x is within the range of value
void freeList(); //A function that returns all the space stored in the oplist
void freeHi(); //A function that returns all the space stored in the hist

#endif