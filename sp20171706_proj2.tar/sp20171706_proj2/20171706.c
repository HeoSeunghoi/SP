#define _CRT_SECURE_NO_WARNINGS
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include <ctype.h>
#include<math.h>
#include<dirent.h>
#include<unistd.h>
#include<sys/types.h>
#include<sys/stat.h>
#include "20171706.h"

int main() {
    opcode = (oplist**)malloc(sizeof(oplist*) * 20);
    symbol = (symtab*)malloc(sizeof(symtab));
    symbol = NULL;
    for (int i = 0; i < 20; i++) { //Allocate virtual memory space
        opcode[i] = (oplist*)malloc(sizeof(oplist));
        opcode[i] = NULL;
    }
    readOpcode();
    if (flag == -1) //If the opcode.txt does not exist, the program is terminated.
        exit(1);

    char str[100]; //String space for command input
    char str_check[100]; //Generated to check if the command is correct
    char check[100]; //Generated to check if the command is correct
    char check2[100]; //Generated to check if the command is correct
    char strSave[100]; //Space to store refined results when correct input comes in
    int trash; //Space to store unused return values
    hist = NULL;
    printf("sicsim>");
    trash = scanf("%[^\n]s", str);
    while (1) { //If nothing is entered, repeat until the correct input is received
        if (str[0] == -51) {
            printf("Retry.\nsicsim>");
            trash = getchar();
            trash = scanf("%[^\n]s", str);
        }
        else
            break;
    }
    //Copy to str_check after removing left and right spaces of str
    strcpy(str, DeleteleftSpace(str));
    strcpy(str, DeleterightSpace(str));
    strcpy(str_check, str);
    reset();
    //Run the appropriate function using str_check.
    while (1) {
        if (strcmp(str_check, "quit") == 0 || strcmp(str_check, "q") == 0)
            break;
        else if (strcmp(str_check, "help") == 0 || strcmp(str_check, "h") == 0) {
            printf("h[elp]\nd[ir]\nq[uit]\nhi[story]\ndu[mp] [start, end]\ne[dit] address, value\nf[ill] start, end, value\nreset\nopcode mnemonic\nopcodelist\nassemble filename\ntype filename\nsymbol\n");
            if (flag == 0) //If correct input, save in hist
                saveHi(str);
        }
        else if (strcmp(str_check, "dir") == 0 || strcmp(str_check, "d") == 0) {
            dir();
            if (flag == 0) //If correct input, save in hist
                saveHi(str);
        }
        else if (strcmp(str_check, "history") == 0 || strcmp(str_check, "hi") == 0) {
            saveHi(str);
            history();
        }
        else if (strcmp(str_check, "dump") == 0 || strcmp(str_check, "du") == 0) {
            strcpy(strSave, dump(str)); //Copy the refined string resulting from the dump function to strSave
            if (flag == 0) //If correct input, save in hist
                saveHi(strSave);
        }
        else if (strcmp(str, "reset") == 0) {
            reset();
            if (flag == 0) //If correct input, save in hist
                saveHi(str);
        }
        else if (strcmp(strtok(str_check, " "), "edit") == 0 || strcmp(strtok(str_check, " "), "e") == 0 || strcmp(strtok(str_check, "\t"), "edit") == 0 || strcmp(strtok(str_check, "\t"), "e") == 0) {
            strcpy(strSave, edit(str)); //Copy the refined string resulting from the edit function to strSave
            if (flag == 0) //If correct input, save in hist
                saveHi(strSave);
        }
        else if (strcmp(strtok(str_check, " "), "fill") == 0 || strcmp(strtok(str_check, " "), "f") == 0 || strcmp(strtok(str_check, "\t"), "fill") == 0 || strcmp(strtok(str_check, "\t"), "f") == 0) {
            strcpy(strSave, fill(str)); //Copy the refined string resulting from the fill function to strSave
            if (flag == 0) //If correct input, save in hist
                saveHi(strSave);
        }
        else if (strcmp(strtok(str_check, " "), "opcode") == 0 || strcmp(strtok(str_check, "\t"), "opcode") == 0) {
            strcpy(strSave, mnemonic(str)); //Copy the refined string resulting from the mnemonic function to strSave
            if (flag == 0) //If correct input, save in hist
                saveHi(strSave);
        }
        else if (strcmp(str_check, "opcodelist") == 0) {
            opcodeList();
            saveHi(str);
        }
        else if (strcmp(strtok(str_check, " "), "assemble") == 0 || strcmp(strtok(str_check, "\t"), "assemble") == 0) {
            strcpy(strSave, assemble(str));
            if (flag == 0) //If correct input, save in hist
                saveHi(strSave);
        }
        else if (strcmp(str_check, "symbol") == 0 || strcmp(str_check, "symbol") == 0) {
            Symbol();
            saveHi(str);
        }
        else if (strcmp(strtok(str_check, " "), "type") == 0 || strcmp(strtok(str_check, "\t"), "type") == 0) {
            strcpy(strSave, type(str));
            if (flag == 0)
                saveHi(strSave);
        }
        else {
            //Copy from str to check and check1 for a certain length.
            strncpy(check, str, 3);
            strncpy(check2, str, 5);
            check[3] = '\0';
            check2[5] = '\0';

            //Execute the appropriate function if conditions are met
            if (strcmp(check, "du ") == 0 || strcmp(check2, "dump ") == 0) {
                strcpy(strSave, dump(str)); //Copy the refined string resulting from the dump function to strSave
                if (flag == 0)
                    saveHi(strSave);
            }
            else if (strcmp(check, "du\t") == 0 || strcmp(check2, "dump\t") == 0) {
                strcpy(strSave, dump(str));
                if (flag == 0)
                    saveHi(strSave);
            }
            else //In case of wrong input
                printf("Wrong.\n");
        }
        //If str is input again
        printf("sicsim>");
        strcpy(str, "@");
        trash = getchar();
        trash = scanf("%[^\n]s", str);
        while (strcmp(str, "@") == 0) { //If nothing is entered in str, repeat until input is entered
            printf("Retry.\nsicsim>");
            trash = getchar();
            trash = scanf("%[^\n]s", str);
        }
        //Copy to str_check after removing left and right spaces of str
        strcpy(str, DeleteleftSpace(str));
        strcpy(str, DeleterightSpace(str));
        strcpy(str_check, str);
        flag = 0;
    }
    //Free all dynamically allocated space before terminating the program
    freeList();
    freeHi();
    FreeSymtab(SaveSymbol);
    Freelistdata();
    flag = trash;
    return 0;
}

void history() {
    int i = 1;
    for (list* print = hist; print != NULL; print = print->next)
        printf("%d\t%s\n", i++, print->hi);
}

void saveHi(char str[]) {
    list* tmp = (list*)malloc(sizeof(list));
    list* mov;
    strcpy(tmp->hi, str);
    tmp->next = NULL;
    if (hist == NULL) //Create space and save data when heist is empty
        hist = tmp;
    else { //Create a new space tmp if not empty and connect to the correct location
        for (mov = hist; mov->next != NULL; mov = mov->next);
        mov->next = tmp;
    }
}

char* dump(char str[]) {
    int i, j, x = adrs / 16;
    int adrss = 0; // variable to store temporary address value when inputted in the form of dump A or dump A or B
    char* a = NULL, * b = NULL; // space for splitting the entered str and storing only the required string
    char check1[100]; // variables to store du and du\t
    char check2[100];// variables to store dump and dump\t
    char* str2 = NULL; //str, space to store non-dump strings when you jog
    int A, B; //variable to store address values
    static char strSave[100]; //space to store refined results
    strSave[0] = '\0';

    if (strcmp(str, "dump") == 0 || strcmp(str, "du") == 0) {
        for (i = x; i < x + 10; i++) {
            //output addresses for virtual memory space
            printf("%05X", adrs);
            adrs += 16;
            //Reset adrs to zero if outside the range of the address
            if (adrs > 1048575)
                adrs = 0;

            for (j = 0; j < 16; j++) { //Outputs data stored in the virtual notepad space in hexadecimal form
                printf(" %02X", shell[i][j]);
            }
            printf(" ;");
            for (j = 0; j < 16; j++) { //Output ASCII code values for data stored in virtual memory space
                if (shell[i][j] < 32 || shell[i][j]>126)
                    printf(".");
                else
                    printf("%c", shell[i][j]);
            }
            printf("\n");
        }
    }
    else { //In case of input in the form of dump A or dump A or B
        strncpy(check1, str, 3);
        check1[3] = '\0';
        strncpy(check2, str, 5);
        check2[5] = '\0';
        if (strcmp(check1, "du ") == 0 || strcmp(check2, "dump ") == 0) {
            //Store dump in str2 and remove left and right spaces in str2
            str = strtok(str, " ");
            str2 = strtok(NULL, "");
            strcpy(str2, DeleterightSpace(str2));
            strcpy(str2, DeleteleftSpace(str2));

            if (str_chr(str2, ',') == 0) { //In case input is made in the form of dump A
                for (i = 0; i < (int)strlen(str2); i++) { //Verify A is Hex
                    A = str2[i];
                    if (isxdigit(A) == 0) {
                        printf("Wrong.\n");
                        flag = -1;
                        return " ";
                    }
                }
                //Ensure that A is in the address range
                A = strtol(str2, NULL, 16);
                if (range(A) == -1) {
                    printf("Over range.\n");
                    flag = -1;
                    return " ";
                }
                //Save temporary address to adrss
                adrss = strtol(str2, NULL, 16);
                adrss = (adrss / 16) * 16;
                for (i = A / 16; i <= A / 16 + 10; i++) { //Output according to output format
                    if (i == A / 16 + 10 && A % 16 == 0) //In case the last digit of A is 0 and all 160 are printed
                        break;
                    //Output memory address
                    if (adrss > 1048575)
                        break;
                    printf("%05X", adrss);
                    adrss += 16;

                    //Outputs only values between the start and end addresses of the addresses
                    if (i == A / 16) {
                        for (j = 0; j < A % 16; j++) {
                            printf("   ");
                        }
                        for (; j < 16; j++) {
                            printf(" %02X", shell[i][j]);
                        }
                    }
                    else if (i == A / 16 + 10) {
                        for (j = 0; j < A % 16; j++) {
                            printf(" %02X", shell[i][j]);
                        }
                        for (; j < 16; j++) {
                            printf("   ");
                        }
                    }
                    else {
                        for (j = 0; j < 16; j++) {
                            printf(" %02X", shell[i][j]);
                        }
                    }

                    printf(" ;");
                    for (j = 0; j < 16; j++) { //Outputs the rest of the input as "." except for the data value of the address range and the value of the output range of the ASCII code
                        if (j < A % 16)
                            printf(".");
                        else if (shell[i][j] < 32 || shell[i][j]>126)
                            printf(".");
                        else
                            printf("%c", shell[i][j]);
                    }
                    printf("\n");
                }
                //Returns a refined string
                strcat(strSave, str);
                strcat(strSave, " ");
                strcat(strSave, str2);
                return strSave;
            }
        }
        else if (strcmp(check1, "du\t") == 0 || strcmp(check2, "dump\t") == 0) {//dump\tA���·� �Է¹޴� ���
            //Operate in the same form as dump A
            str = strtok(str, "\t");
            str2 = strtok(NULL, "");

            strcpy(str2, DeleterightSpace(str2));
            strcpy(str2, DeleteleftSpace(str2));

            if (str_chr(str2, ',') == 0) {
                for (i = 0; i < (int)strlen(str2); i++) {
                    A = str2[i];
                    if (isxdigit(A) == 0) {
                        printf("Wrong.\n");
                        flag = -1;
                        return " ";
                    }
                }
                A = strtol(str2, NULL, 16);
                if (range(A) == -1) {
                    printf("Over range.\n");
                    flag = -1;
                    return " ";
                }

                adrss = strtol(str2, NULL, 16);
                adrss = (adrss / 16) * 16;
                for (i = A / 16; i <= A / 16 + 10; i++) {

                    if (i == A / 16 + 10 && A % 16 == 0)
                        break;
                    if (adrss > 1048575)
                        break;
                    printf("%05X", adrss);
                    adrss += 16;

                    if (i == A / 16) {
                        for (j = 0; j < A % 16; j++) {
                            printf("   ");
                        }
                        for (; j < 16; j++) {
                            printf(" %02X", shell[i][j]);
                        }
                    }
                    else if (i == A / 16 + 10) {
                        for (j = 0; j < A % 16; j++) {
                            printf(" %02X", shell[i][j]);
                        }
                        for (; j < 16; j++) {
                            printf("   ");
                        }
                    }
                    else {
                        for (j = 0; j < 16; j++) {
                            printf(" %02X", shell[i][j]);
                        }
                    }

                    printf(" ;");
                    for (j = 0; j < 16; j++) {
                        if (j < A % 16)
                            printf(".");
                        else if (shell[i][j] < 32 || shell[i][j]>126)
                            printf(".");
                        else
                            printf("%c", shell[i][j]);
                    }
                    printf("\n");
                }
                strcat(strSave, str);
                strcat(strSave, " ");
                strcat(strSave, str2);
                return strSave;
            }
        }
        else if (str_chr(str2, ',') != 1) { //"," recognized as invalid input if there are more than two "," processed above if there are zero.
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
        //Store the starting and ending addresses of the outputs in a and b
        a = strtok(str2, ",");
        b = strtok(NULL, "");

        //Make sure a and b are NULL and remove left and right spaces if not NULL
        if (a != NULL) {
            strcpy(a, DeleterightSpace(a));
            strcpy(a, DeleteleftSpace(a));
        }
        else {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
        if (b != NULL) {
            strcpy(b, DeleterightSpace(b));
            strcpy(b, DeleteleftSpace(b));
        }
        else {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }

        if (a == NULL) {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
        //Terminate a function unless a and b are hexadecimal
        for (i = 0; i < (int)strlen(a); i++) {
            A = a[i];
            if (isxdigit(A) == 0) {
                printf("Wrong.\n");
                flag = -1;
                return " ";
            }
        }
        for (i = 0; i < (int)strlen(b); i++) {
            B = b[i];
            if (isxdigit(B) == 0) {
                printf("Wrong.\n");
                flag = -1;
                return " ";
            }
        }

        //Ensure that a and b are in the correct range
        A = strtol(a, NULL, 16);
        if (range(A) == -1) {
            printf("Over range.\n");
            flag = -1;
            return " ";
        }
        B = strtol(b, NULL, 16);
        if (range(B) == -1) {
            printf("Over range.\n");
            flag = -1;
            return " ";
        }

        if (A > B) { //If A is greater than B, treat as invalid input
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
        //Save address value to start output
        adrss = strtol(str2, NULL, 16);
        adrss = (adrss / 16) * 16;

        for (i = A / 16; i <= B / 16; i++) { //Output data between start and end ranges to the output format

            printf("%05X", adrss);
            adrss += 16;

            if (i == A / 16) {
                for (j = 0; j < A % 16; j++) {
                    printf("   ");
                }
                if (i != B / 16) {
                    for (; j < 16; j++) {
                        printf(" %02X", shell[i][j]);
                    }
                }
                else {
                    for (; j <= B % 16; j++) {
                        printf(" %02X", shell[i][j]);
                    }
                    for (; j < 16; j++) {
                        printf("   ");
                    }
                }

            }
            else if (i != B / 16) {
                for (j = 0; j < 16; j++) {
                    printf(" %02X", shell[i][j]);
                }
            }
            else if (i == B / 16) {
                for (j = 0; j <= B % 16; j++) {
                    printf(" %02X", shell[i][j]);
                }
                for (; j < 16; j++) {
                    printf("   ");
                }
            }
            printf(" ;");
            for (j = 0; j < 16; j++) {
                if (j < A % 16 || j>B % 16)
                    printf(".");
                else if (shell[i][j] < 32 || shell[i][j]>126)
                    printf(".");
                else
                    printf("%c", shell[i][j]);
            }
            printf("\n");
        }
    }
    //Returns a refined string
    strcat(strSave, str);
    if (a != NULL) {
        strcat(strSave, " ");
        strcat(strSave, a);
    }
    if (b != NULL) {
        strcat(strSave, ", ");
        strcat(strSave, b);
    }
    return strSave;
}

char* DeleterightSpace(char* s)
{
    char* line = NULL;
    line = (char*)malloc(sizeof(char) * 100);
    char* end;
    strcpy(line, s);
    end = line + strlen(line) - 1;
    while (end != line && isspace(*end))
        end--;
    *(end + 1) = '\0';
    strcpy(s, line);
    free(line);
    return s;
}

char* DeleteleftSpace(char* s) {
    char* str;
    str = s;
    while (*str != '\0') {
        if (isspace(*str))
            str++;
        else {
            s = str;
            break;
        }
    }
    return s;
}

int str_chr(char* s, char c) {
    int i;
    int count = 0;
    for (i = 0; i < (int)strlen(s); i++) {
        if (s[i] == c)
            count++;
    }
    return count;
}

char* edit(char* str) {
    int i, j, A = 0, B = 0;
    char* str2 = str;
    char* a = NULL;
    char* b = NULL;
    char check1[100];
    char check2[100];
    static char strSave[100];
    strSave[0] = '\0';

    //Copy str to check1 and check2 for a certain length and verify that it is the correct input
    strncpy(check1, str, 2);
    check1[2] = '\0';
    strncpy(check2, str, 5);
    check2[5] = '\0';

    //Split str according to each standard and remove left and right spaces of str2
    if (strcmp(check1, "e ") == 0 || strcmp(check2, "edit ") == 0) { //The string starts with e or edit.
        str = strtok(str, " ");
        str2 = strtok(NULL, "");
    }
    else if (strcmp(check1, "e\t") == 0 || strcmp(check2, "edit\t") == 0) { //e\tȤ�� edit\t�� ���ڿ��� ���۵Ǵ� ���
        str = strtok(str, "\t");
        str2 = strtok(NULL, "");
    }
    strcpy(str2, DeleterightSpace(str2));
    strcpy(str2, DeleteleftSpace(str2));


    if (str_chr(str2, ',') != 1) { //str2�� ','�� 1���� �ƴ� ��� �߸��� �Է����� ó��
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    //Store address values and data values in a and b if the input is correct
    a = strtok(str2, ",");
    b = strtok(NULL, "");
    //If a and b are not NULL, remove left and right spaces
    if (a != NULL) {
        strcpy(a, DeleterightSpace(a));
        strcpy(a, DeleteleftSpace(a));
    }
    else {
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    if (b != NULL) {
        strcpy(b, DeleterightSpace(b));
        strcpy(b, DeleteleftSpace(b));
    }
    else {
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    //Verify that a and b are hexadecimal
    for (i = 0; i < (int)strlen(a); i++) {
        A = a[i];
        if (isxdigit(A) == 0) {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
    }
    for (i = 0; i < (int)strlen(b); i++) {
        B = b[i];
        if (isxdigit(B) == 0) {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
    }
    //Verify that a is the address value range and that b is included in the data value range.
    A = strtol(a, NULL, 16);
    if (range(A) == -1) {
        printf("Over range.\n");
        flag = -1;
        return " ";
    }
    B = strtol(b, NULL, 16);
    if (rangeV(B) == -1) {
        printf("Over range.\n");
        flag = -1;
        return " ";
    }
    //Store the correct shell location in i and j
    i = A / 16;
    j = A % 16;
    shell[i][j] = B;

    //Returns a refined string
    strcat(strSave, str);
    if (a != NULL) {
        strcat(strSave, " ");
        strcat(strSave, a);
    }
    if (b != NULL) {
        strcat(strSave, ", ");
        strcat(strSave, b);
    }
    return strSave;
}

char* fill(char* str) {
    int i, j, A = 0, B = 0, C = 0;
    char* str2 = NULL;
    char* a = NULL;
    char* b = NULL;
    char* c = NULL;
    char check1[100];
    char check2[100];
    static char strSave[100];
    strSave[0] = '\0';

    strncpy(check1, str, 2);
    check1[2] = '\0';
    strncpy(check2, str, 5);
    check2[5] = '\0';
    //Split str according to each standard and remove left and right spaces of str2
    if (strcmp(check1, "f ") == 0 || strcmp(check2, "fill ") == 0) {
        str = strtok(str, " ");
        str2 = strtok(NULL, "");
    }
    else if (strcmp(check1, "f\t") == 0 || strcmp(check2, "fill\t") == 0) {
        str = strtok(str, "\t");
        str2 = strtok(NULL, "");
    }
    if (str2 != NULL) {
        strcpy(str2, DeleterightSpace(str2));
        strcpy(str2, DeleteleftSpace(str2));
    }

    if (str2 == NULL) {
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    if (str_chr(str2, ',') != 2) {//If the number of ',' contained in str2 is not 2, it is recognized as an invalid input
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    //Start, end, and store data values in a, b, and c
    a = strtok(str2, ",");
    b = strtok(NULL, ",");
    c = strtok(NULL, "");

    //Check if a, b, and c are NULL and remove left and right spaces if not
    if (a != NULL) {
        strcpy(a, DeleterightSpace(a));
        strcpy(a, DeleteleftSpace(a));
    }
    else {
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    if (b != NULL) {
        strcpy(b, DeleterightSpace(b));
        strcpy(b, DeleteleftSpace(b));
    }
    else {
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }
    if (c != NULL) {
        strcpy(c, DeleterightSpace(c));
        strcpy(c, DeleteleftSpace(c));
    }
    else {
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }

    //Check if a, b, and c are hexadecimal
    for (i = 0; i < (int)strlen(a); i++) {
        A = a[i];
        if (isxdigit(A) == 0) {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
    }
    for (i = 0; i < (int)strlen(b); i++) {
        B = b[i];
        if (isxdigit(B) == 0) {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
    }
    for (i = 0; i < (int)strlen(c); i++) {
        C = c[i];
        if (isxdigit(C) == 0) {
            printf("Wrong.\n");
            flag = -1;
            return " ";
        }
    }
    //Ensure that a, b, and c are in the correct range
    A = strtol(a, NULL, 16);
    B = strtol(b, NULL, 16);
    C = strtol(c, NULL, 16);
    if (range(A) == -1 || range(B) == -1 || rangeV(C) == -1) {
        printf("Over range.\n");
        flag = -1;
        return " ";
    }

    if (A > B) {//If the start address is smaller than the end address, treat it as an invalid input
        printf("Wrong.\n");
        flag = -1;
        return " ";
    }

    //Change the data value between a and b to c
    for (i = A / 16; i <= B / 16; i++) {
        if (i == A / 16) {
            if (A / 16 == B / 16) {
                for (j = A % 16; j <= B % 16; j++) {
                    shell[i][j] = C;
                }
            }
            else {
                for (j = A % 16; j < 16; j++) {
                    shell[i][j] = C;
                }
            }
        }
        else {
            if (i == B / 16) {
                for (j = 0; j <= B % 16; j++) {
                    shell[i][j] = C;
                }
            }
            else {
                for (j = 0; j < 16; j++) {
                    shell[i][j] = C;
                }
            }
        }
    }
    //Returns a refined string
    strcat(strSave, str);
    if (a != NULL) {
        strcat(strSave, " ");
        strcat(strSave, a);
    }
    if (b != NULL) {
        strcat(strSave, ", ");
        strcat(strSave, b);
    }
    if (c != NULL) {
        strcat(strSave, ", ");
        strcat(strSave, c);
    }
    return strSave;
}

void dir() {
    int count = 0;
    struct stat buf;
    DIR* dir = NULL;
    struct dirent* entry = NULL;

    dir = opendir(".");
    if (dir == NULL) {
        printf("current directory error\n");
        exit(1);
    }
    while ((entry = readdir(dir)) != NULL) {
        lstat(entry->d_name, &buf);
        if (count < 3) { //If you haven't printed four yet
            if (S_ISDIR(buf.st_mode)) //directory
                printf("%15s/", entry->d_name);
            else if (S_IEXEC & buf.st_mode) //Executable file
                printf("%15s*", entry->d_name);
            else { //the rest of the case
                printf("%15s", entry->d_name);
            }
            count++;
        }
        else { //If the fourth output is output
            if (S_ISDIR(buf.st_mode))
                printf("%15s/\n", entry->d_name);
            else if (S_IEXEC & buf.st_mode)
                printf("%15s*\n", entry->d_name);
            else {
                printf("%15s\n", entry->d_name);
            }
            count = 0;
        }
    }
    printf("\n");
    closedir(dir);
}

void reset() {
    for (int i = 0; i < 65536; i++)
        for (int j = 0; j < 16; j++)
            shell[i][j] = 0;
}

void readOpcode() {
    //Verify that the opcode.txt file exists
    FILE* fp = fopen("opcode.txt", "r");
    if (fp == NULL) {
        printf("There is no file.\n");
        flag = -1;
        fclose(fp);
        return;
    }
    int hash;
    int Code = 0;
    int trash;
    char name[100];
    char num[100];
    char code[100];
    oplist* mov;
    //Read the data stored in opcode.txt one line to the end of the file and save the data to the oplist
    trash = fscanf(fp, "%s %s %s", code, name, num);
    while (!feof(fp)) {
        //Store read data in mk
        oplist* mk = (oplist*)malloc(sizeof(oplist));
        Code = strtol(code, NULL, 16);
        mk->code = Code;
        strcpy(mk->name, name);
        strcpy(mk->num, num);
        mk->next = NULL;
        hash = getHash(name);
        if (opcode[hash] == NULL) //if i opcode[hash] is NULL
            opcode[hash] = mk;
        else { //link opcode[hash]
            mov = opcode[hash];
            while (mov->next != NULL) {//Save data at the end of opcode[i]
                mov = mov->next;
            }
            mov->next = mk;
        }
        trash = fscanf(fp, "%s %s %s", code, name, num);
    }
    Code = trash;
    fclose(fp);
}

char* mnemonic(char* str) {
    int code;
    char* name = NULL;
    static char strSave[100];
    strSave[0] = '\0';
    char check[100] = { '\0' };
    //Distinguish between "opcode" and "opcode\t" and divide them into names and str.
    strncpy(check, str, 7);
    if (strcmp(check, "opcode ") == 0) {
        str = strtok(str, " ");
        name = strtok(NULL, "");
    }
    else if (strcmp(check, "opcode\t") == 0) {
        str = strtok(str, "\t");
        name = strtok(NULL, "");
    }
    //Verify name is NULL and remove left and right spaces
    if (name == NULL) {
        printf("Wrong\n");
        flag = -1;
        return " ";
    }
    else {
        strcpy(name, DeleterightSpace(name));
        strcpy(name, DeleteleftSpace(name));
    }
    code = getopcode(name);
    if (code == -1) {//Treat as invalid input if not in the list
        flag = -1;
        printf("Wrong.\n");
        return " ";
    }
    printf("opcode is %02X\n", code);
    //Returns a refined string
    strcat(strSave, str);
    if (name != NULL) {
        strcat(strSave, " ");
        strcat(strSave, name);
    }
    return strSave;
}

void opcodeList() {
    int i;
    oplist* mov;

    for (i = 0; i < 20; i++) {
        mov = opcode[i];
        printf("%d :", i);
        if (mov == NULL) {
            printf("\n");
            continue;
        }
        while (mov->next != NULL) {
            printf(" [%s,%02X] ->", mov->name, mov->code);
            mov = mov->next;
        }
        printf(" [%s,%02X]\n", mov->name, mov->code);
    }
}

int range(int x) {
    if (x < 0 || x>1048575)
        return -1;
    else return 0;
}

int rangeV(int x) {
    if (x < 0 || x>255)
        return -1;
    else return 0;
}

void freeList() {
    oplist* mov;
    for (int i = 0; i < 20; i++) {
        mov = opcode[i];
        if (mov == NULL)
            continue;
        while (opcode[i] != NULL) {
            mov = opcode[i];
            opcode[i] = opcode[i]->next;
            free(mov);
        }
    }
}

void freeHi() {
    list* mov;
    mov = hist;

    if (mov == NULL)
        return;
    while (hist != NULL) {
        mov = hist;
        hist = hist->next;
        free(mov);
    }
}

int getHash(char* s) {
    int len = strlen(s);
    int hash = 0;
    for (int i = 0; i < len; i++)
        hash += (int)s[i];
    hash %= 20;
    return hash;
}

char* assemble(char* str) { // Generate .obj and .lst with the data in the .asm file if the correct input is received.
    char name[100]; // String that stores the name of the file to be read
    static char strtemp[100]; // String for storing strings with refined input and storing them in the history structure
    strcpy(strtemp, str);
    if (str[8] == ' ') { // When separated by a space between the name of the file and the anemble
        strcpy(strtemp, strtok(strtemp, " "));
        strcpy(name, strtok(NULL, ""));
        strcat(strtemp, " ");
        strcpy(name, DeleteleftSpace(name));
        strcpy(name, DeleterightSpace(name));
        strcat(strtemp, name);
    }
    else if (str[8] == '\t') { // When separated by a tap between the name of the file and the anemble
        strcpy(strtemp, strtok(strtemp, "\t"));
        strcpy(name, strtok(NULL, ""));
        strcat(strtemp, " ");
        strcpy(name, DeleteleftSpace(name));
        strcpy(name, DeleterightSpace(name));
        strcat(strtemp, name);
    }
    FILE* fp_r = fopen(name, "r"); // open file
    if (fp_r == NULL) { // The file with the entered name does not exist
        printf("File is not exsit.\n");
        flag = -1;
        return " ";
    }
    if (strcmp(str + strlen(str) - 4, ".asm") != 0) { // If not .asm
        printf("It is not asmFile.\n");
        flag = -1;
        return " ";
    }

    pass1(name);
    if (flag == -1) { // Error in obtaining LOCCTR
        //symbtab free
        FreeSymtab(symbol), Freelistdata();
        return " ";
    }
    pass2();
    if (flag == -1) { // Error in obtaining object code
        //symtab free
        FreeSymtab(symbol), Freelistdata();
        return " ";
    }
    strcpy(name, strtok(name, "."));
    makeLIST(name); // make .lst
    makeOBJ(name); // make .obj
    savesymbol(); // If the correct input is received, copy the information in the symbol.
    FreeSymtab(symbol); // Free Symbol that created the file and made dynamic assignments.
    Freelistdata(); // Free asmfile data that created the file and made dynamic assignments.
    printf("[%s.lst], [%s.obj]\n", name, name);
    return strtemp;
}

void pass1(char* str) {
    FILE* fp = fopen(str, "r"); // file open
    int i = 0;
    int sflag = 0, eflag = 0, trash; // Variables that confirm the normal presence of START and END
    char line[100]; // String for storing .asm's information one line at a time
    char label[100]; // String for storing labels, opcode, and openand on each line
    char opcode[100];
    char operand[100];
    line[0] = '\0';
    label[0] = '\0';
    opcode[0] = '\0';
    operand[0] = '\0';
    listdata* tmpL; //Used to store .asm's data in order
    listdata* movL;

    if (fscanf(fp, "%[^\n]s", line) != EOF) { // read start line
        fgetc(fp);
        if (line[0] == ' ') // not exist label
            trash = sscanf(line, "%s %[^\n]s", opcode, operand);
        else // exist label : label�� �ִ� ���
            trash = sscanf(line, "%s %s %[^\n]s", label, opcode, operand);

        if (strcmp(opcode, "START") == 0) { // save linemun, lable, opcode, operand in data struct
            sflag = 1;
            tmpL = (listdata*)malloc(sizeof(listdata));
            tmpL->lineNum = line_num++ * 5;
            strcpy(tmpL->label, label);
            strcpy(tmpL->opcode, opcode);
            strcpy(tmpL->operand, operand);
            tmpL->objcode[0] = '\0';
            tmpL->next = NULL;
            LOCCTR = strtol(operand, NULL, 16);
            tmpL->LOCCTR = LOCCTR;
            data = tmpL;
        }
    }
    while (fscanf(fp, "%[^\n]s", line) != EOF) { // Read file end by end line
        fgetc(fp);
        if (line[0] == ' ')
            trash = sscanf(line, "%s %[^\n]s", opcode, operand);
        else
            trash = sscanf(line, "%s %s %[^\n]s", label, opcode, operand);
        // save linemun, lable, opcode, operand in data struct
        tmpL = (listdata*)malloc(sizeof(listdata));
        tmpL->lineNum = line_num++ * 5;
        strcpy(tmpL->label, label);
        strcpy(tmpL->opcode, opcode);
        strcpy(tmpL->operand, operand);
        tmpL->objcode[0] = '\0';
        tmpL->next = NULL;

        if (strcmp(opcode, "END") == 0) { //if opcode is END
            eflag = 1;
            tmpL->LOCCTR = -1;
            for (movL = data; movL->next != NULL; movL = movL->next);
            movL->next = tmpL; // Store data in .asm in order
            break;
        }
        if (label[0] == '.') { // explanatory notes
            tmpL->LOCCTR = -1;
            for (movL = data; movL->next != NULL; movL = movL->next);
            movL->next = tmpL;
            label[0] = '\0';
            opcode[0] = '\0';
            operand[0] = '\0';
            continue;
        }
        if (label[0] != '\0') { // If there is a label, store the label and LOCCTR in the symbol.
            Addsym(label, LOCCTR);
            if (flag == -1) {
                printf("Error %d : %s\n", (line_num + 1) * 5, line);
                fclose(fp);
                return;
            }
        }
        if (strcmp(opcode, "WORD") == 0) { // If opcode is WORD
            if (operand[0] >= '0' && operand[0] <= '9');
            else {
                printf("Error %d : %s\n", (line_num + 1) * 5, line);
                flag = -1;
                fclose(fp);
                return;
            }
            tmpL->LOCCTR = LOCCTR;
            for (movL = data; movL->next != NULL; movL = movL->next);
            movL->next = tmpL;
            LOCCTR += 3;
        }
        else if (strcmp(opcode, "RESW") == 0) { // If opcode is RESW
            for (i = 0; (unsigned int)i < strlen(operand); i++) {
                if (operand[i] >= '0' && operand[i] <= '9');
                else {
                    printf("Error %d : %s\n", (line_num + 1) * 5, line);
                    flag = -1;
                    fclose(fp);
                    return;
                }
            }
            tmpL->LOCCTR = LOCCTR;
            for (movL = data; movL->next != NULL; movL = movL->next);
            movL->next = tmpL;
            LOCCTR += (atoi(operand) * 3);
        }
        else if (strcmp(opcode, "RESB") == 0) { // If opcode is RESB
            for (i = 0; (unsigned int)i < strlen(operand); i++) {
                if (operand[i] >= '0' && operand[i] <= '9');
                else {
                    printf("Error %d : %s\n", (line_num + 1) * 5, line);
                    flag = -1;
                    fclose(fp);
                    return;
                }
            }
            tmpL->LOCCTR = LOCCTR;
            for (movL = data; movL->next != NULL; movL = movL->next);
            movL->next = tmpL;
            LOCCTR += atoi(operand);
        }
        else if (strcmp(opcode, "BYTE") == 0) {// If opcode is BYTE
            if (operand[0] == 'C') { // In case of char entering the operand
                if (operand[1] == '\'' && operand[strlen(operand) - 1] == '\'') {
                    for (i = 2; (unsigned int)i < strlen(operand) - 1; i++) {
                        if (operand[i] >= 'A' && operand[i] <= 'Z');
                        else {
                            printf("Error %d : %s\n", (line_num + 1) * 5, line);
                            flag = -1;
                            fclose(fp);
                            return;
                        }
                    }
                    tmpL->LOCCTR = LOCCTR;
                    for (movL = data; movL->next != NULL; movL = movL->next);
                    movL->next = tmpL;
                    LOCCTR += strlen(operand) - 3;
                }
            }
            else if (operand[0] == 'X') {// In case of Hex entering the operand
                if (operand[1] == '\'' && operand[strlen(operand) - 1] == '\'') {
                    for (i = 2; (unsigned int)i < strlen(operand) - 1; i++) {
                        if (isxdigit(operand[i]));
                        else {
                            printf("Error %d : %s\n", (line_num + 1) * 5, line);
                            flag = -1;
                            fclose(fp);
                            return;
                        }
                    }
                    tmpL->LOCCTR = LOCCTR;
                    for (movL = data; movL->next != NULL; movL = movL->next);
                    movL->next = tmpL;
                    LOCCTR += (strlen(operand) - 3) / 2;
                }
            }
        }
        else if (strcmp(opcode, "BASE") == 0) { // If there is no label and BASE enters the opcode,
            tmpL->LOCCTR = -1;
            for (movL = data; movL->next != NULL; movL = movL->next);
            movL->next = tmpL;
        }
        else if (strcmp(opcode, "WORD") == 0) { // If there is no label and WORD enters the opcode,
            for (i = 0; (unsigned int)i < strlen(operand); i++) {
                if (operand[i] < '0' || operand[i] > '9') {
                    printf("Error %d : %s\n", (line_num + 1) * 5, line);
                    flag = -1;
                    fclose(fp);
                    return;
                }
            }
            tmpL->LOCCTR = LOCCTR;
            for (movL = data; movL->next != NULL; movL = movL->next);
            movL->next = tmpL;
            LOCCTR += 3;
        }
        else {
            if (format(opcode) == -1) { // If there is no label and the opcode does not exist in the optab
                printf("Error %d : %s\n", (line_num + 1) * 5, line);
                flag = -1;
                fclose(fp);
                return;
            }
            tmpL->LOCCTR = LOCCTR;
            for (movL = data; movL->next != NULL; movL = movL->next);
            movL->next = tmpL;
            LOCCTR += format(opcode);
        }
        label[0] = '\0';
        opcode[0] = '\0';
        operand[0] = '\0';
    }
    if (sflag == 0)
        printf("START is not exist.\n");
    if (eflag == 0)
        printf("END is not exist.\n");
    fclose(fp);
    sflag = trash;
}

void pass2() { //PC���� ��� �ֽ�ȭ
    listdata* mov = data;
    char bytec[5];
    int word = 0;
    for (mov = data; mov != NULL; mov = mov->next) { // Reads all data stored in pass1 to pass1
        if (strcmp(mov->opcode, "START") == 0) // opcode is START
            mov->objcode[0] = '\0';
        else if (strcmp(mov->opcode, "END") == 0) // opcode is END
            mov->objcode[0] = '\0';
        else if (mov->label[0] == '.') // opcode is explanatory notes
            mov->objcode[0] = '\0';
        else if (strcmp(mov->opcode, "BASE") == 0) { // opcode is BASE
            mov->objcode[0] = '\0';
            BASE = getSymbol(mov->operand);
        }
        else if (strcmp(mov->opcode, "RESW") == 0 || strcmp(mov->opcode, "RESB") == 0) // opcode is RESW or RESB
            mov->objcode[0] = '\0';
        else if (strcmp(mov->opcode, "BYTE") == 0) { // opcode is BYTE
            if (mov->operand[0] == 'C') {
                for (int i = 2; (unsigned int)i < strlen(mov->operand) - 1; i++) {
                    if (i == 2)
                        sprintf(mov->objcode, "%X", (int)mov->operand[2]);
                    else {
                        sprintf(bytec, "%X", (int)mov->operand[i]);
                        strcat(mov->objcode, bytec);
                    }
                }
                mov->objcode[(strlen(mov->operand) - 3) * 2] = '\0';
            }
            else if (mov->operand[0] == 'X') {
                for (int i = 2; (unsigned int)i < strlen(mov->operand) - 1; i++)
                    mov->objcode[i - 2] = mov->operand[i];
                mov->objcode[strlen(mov->operand) - 3] = '\0';
            }
        }
        else if (strcmp(mov->opcode, "WORD") == 0) {
            word = atoi(mov->operand);
            sprintf(mov->objcode, "%06X", word);
        }
        else
            getobjcode(mov);
        if (flag == -1)
            return;
    }
}

void getobjcode(listdata* mov) {
    listdata* getPC = mov->next; // A struct variable that stores information from the following lines to obtain PC values
    char line[100]; // Array for storing lines currently being read
    char result[100];
    char imad[100];
    char freeuse[100];
    char r1[10];
    char r2[10];
    int i = 0, PC = 0, k = 0, flagL = 0;
    imad[0] = '\0', result[0] = '\0', r1[0] = '\0', r2[0] = '\0', line[0] = '\0';
    strcat(line, mov->label);
    for (i = 0; (unsigned int)i < 6 - strlen(mov->label); i++)
        strcat(line, " ");
    strcat(line, mov->opcode);
    for (i = 0; (unsigned int)i < 6 - strlen(mov->opcode); i++)
        strcat(line, " ");
    strcat(line, mov->operand);

    if (mov->operand[0] == '\0') // no label
        flagL = 1;
    if (str_chr(mov->operand, ',') == 1) { // In case two factors of operand are found
        strcpy(freeuse, mov->operand);
        strcpy(r1, strtok(freeuse, ","));
        strcpy(r2, strtok(NULL, ","));
        freeuse[0] = '\0';
    }
    else strcpy(r1, mov->operand); //In case one factors of operand are found
    if (format(mov->opcode) == 1) { // format 1
        sprintf(freeuse, "%X", getopcode(mov->opcode));
        strcpy(mov->objcode, freeuse);
    }
    else if (format(mov->opcode) == 2) { // foramt2
        if (getopcode(mov->opcode) < 16) {
            result[0] = '0';
            sprintf(result + 1, "%X", getopcode(mov->opcode));
        }
        else sprintf(result, "%X", getopcode(mov->opcode));
        strcat(result, getmn(mov->operand));
        result[4] = '\0';
        strcpy(mov->objcode, result);
    }
    else if (format(mov->opcode) == 3) { // format 3
        if (r1[0] == '#') { // immediated addressing
            if (r1[1] >= 'A' && r1[1] <= 'Z') {//ex) #LENGTH
                for (i = 1; (unsigned int)i < strlen(r1); i++)
                    imad[i - 1] = r1[i];
                imad[i - 1] = '\0';
                if (getopcode(mov->opcode) + 1 < 16) {
                    result[0] = '0';
                    sprintf(result + 1, "%X", getopcode(mov->opcode) + 1);
                }
                else sprintf(result, "%X", getopcode(mov->opcode) + 1);
                if (strcmp(result, "0") == 0) {
                    printf("Error %d : %s\n", mov->lineNum, line);
                    flag = -1;
                    return;
                }
                while (getPC->LOCCTR == -1) getPC = getPC->next;
                PC = getPC->LOCCTR;
                if (getSymbol(imad) >= PC - 2048 && getSymbol(imad) <= PC + 2047) {//check PC relative
                    // n = 0, i = 1, x = ?, b = 0, p = 1, e = 0
                    if (checkXbit(mov->operand) == 1)
                        strcat(result, "A");
                    else
                        strcat(result, "2");
                    sprintf(freeuse, "%X", getSymbol(imad) - PC);
                    if (strlen(freeuse) > 3) {
                        for (i = strlen(freeuse) - 3; (unsigned int)i < strlen(freeuse); i++) {
                            k = strlen(result);
                            result[k] = freeuse[i];
                            result[k + 1] = '\0';
                        }
                    }
                    else { // can't use PC relative
                        for (i = strlen(freeuse); i < 3; i++) strcat(result, "0");
                        strcat(result, freeuse);
                    }
                    strcpy(mov->objcode, result);
                }
                else if (getSymbol(imad) >= BASE && getSymbol(imad) <= BASE + 4095 && BASE != -1) {//check BASE relative
                    // n = 0, i = 1, x = ?, b = 1, p = 0, e = 0
                    if (checkXbit(mov->operand) == 1)
                        strcat(result, "C");
                    else
                        strcat(result, "4");
                    sprintf(freeuse, "%X", getSymbol(imad) - BASE);
                    if (strlen(freeuse) > 3) {
                        for (i = strlen(freeuse) - 3; (unsigned int)i < strlen(freeuse); i++) {
                            k = strlen(result);
                            result[k] = freeuse[i];
                            result[k + 1] = '\0';
                        }
                    }
                    else {
                        for (i = strlen(freeuse); i < 3; i++) strcat(result, "0");
                        strcat(result, freeuse);
                    }
                    strcpy(mov->objcode, result);
                }
                else {
                    flag = -1;
                    printf("Error %d : %s\n", mov->lineNum, line);
                    return;
                }
            }
            else { // n = 0, i = 1 : direct addressing
                for (i = 1; (unsigned int)i < strlen(r1); i++) {
                    if (isxdigit(r1[i]) == 0) break;
                    imad[i - 1] = r1[i];
                }
                imad[i - 1] = '\0';
                if ((unsigned int)i != strlen(r1)) {
                    flag = -1;
                    printf("Error %d : %s\n", mov->lineNum, line);
                    return;
                }
                if (getopcode(mov->opcode) + 1 < 16) {
                    result[0] = '0';
                    sprintf(result + 1, "%X", getopcode(mov->opcode) + 1);
                }
                else sprintf(result, "%X", getopcode(mov->opcode) + 1);
                if (checkXbit(mov->operand) == 1)
                    strcat(result, "8");
                else
                    strcat(result, "0");
                for (i = 0; i < 3; i++) {
                    if ((unsigned int)i < 3 - strlen(imad))
                        strcat(result, "0");
                }
                strcat(result, imad);
                strcpy(mov->objcode, result);
            }
        }
        else if (r1[0] == '@') { //n = 1, i = 0 : indirect addressing
            for (i = 1; (unsigned int)i < strlen(r1); i++)
                imad[i - 1] = r1[i];
            imad[i - 1] = '\0';
            if (getopcode(mov->opcode) + 2 < 16) {
                result[0] = '0';
                sprintf(result + 1, "%X", getopcode(mov->opcode) + 2);
            }
            else sprintf(result, "%X", getopcode(mov->opcode) + 2);
            if (strcmp(result, "1") == 0) {
                printf("Error %d : %s\n", mov->lineNum, line);
                flag = -1;
                return;
            }
            //@LABEL
            while (getPC->LOCCTR == -1) getPC = getPC->next;
            PC = getPC->LOCCTR;
            if (getSymbol(imad) >= PC - 2048 && getSymbol(imad) <= PC + 2047) { // can use PC relative
                // n = 1, i = 0, x = ?, b = 0, p = 1, e = 0
                if (checkXbit(mov->operand) == 1)
                    strcat(result, "A");
                else
                    strcat(result, "2");
                sprintf(freeuse, "%X", getSymbol(imad) - PC);
                if (strlen(freeuse) > 3) {
                    for (i = strlen(freeuse) - 3; (unsigned int)i < strlen(freeuse); i++) {
                        k = strlen(result);
                        result[k] = freeuse[i];
                        result[k + 1] = '\0';
                    }
                }
                else {
                    for (i = strlen(freeuse); i < 3; i++) strcat(result, "0");
                    strcat(result, freeuse);
                }
                strcpy(mov->objcode, result);
            }
            else if (getSymbol(imad) >= BASE && getSymbol(imad) <= BASE + 4095 && BASE != -1) { // can use BASE relative
                // n = 0, i = 1, x = ?, b = 1, p = 0, e = 0
                if (checkXbit(mov->operand) == 1)
                    strcat(result, "C");
                else
                    strcat(result, "4");
                sprintf(freeuse, "%X", getSymbol(imad) - BASE);
                if (strlen(freeuse) > 3) {
                    for (i = strlen(freeuse) - 3; (unsigned int)i < strlen(freeuse); i++) {
                        k = strlen(result);
                        result[k] = freeuse[i];
                        result[k + 1] = '\0';
                    }
                }
                else {
                    for (i = strlen(freeuse); i < 3; i++) strcat(result, "0");
                    strcat(result, freeuse);
                }
                strcpy(mov->objcode, result);
            }
            else {
                flag = -1;
                printf("Error %d : %s\n", mov->lineNum, line);
                return;
            }
        }
        else if (getSymbol(r1) != -1 || flagL == 1) {
            if (getopcode(mov->opcode) + 3 < 16) {
                result[0] = '0';
                sprintf(result + 1, "%X", getopcode(mov->opcode) + 3);
            }
            else sprintf(result, "%X", getopcode(mov->opcode) + 3); //n = 1, i = 1 : simple addressing
            if (flagL == 1) {
                for (i = 2; i < 6; i++) strcat(result, "0");
                result[i] = '\0';
                strcpy(mov->objcode, result);
                return;
            }
            while (getPC->LOCCTR == -1) getPC = getPC->next;
            PC = getPC->LOCCTR;
            if (getSymbol(r1) >= PC - 2048 && getSymbol(r1) <= PC + 2047) {// can use PC relative
                // n = 1, i = 1, x = ?, b = 0, p = 1, e = 0
                if (checkXbit(mov->operand) == 1)
                    strcat(result, "A");
                else
                    strcat(result, "2");
                sprintf(freeuse, "%X", getSymbol(r1) - PC);
                if (strlen(freeuse) > 3) {
                    for (i = strlen(freeuse) - 3; (unsigned int)i < strlen(freeuse); i++) {
                        k = strlen(result);
                        result[k] = freeuse[i];
                        result[k + 1] = '\0';
                    }
                }
                else {
                    for (i = strlen(freeuse); i < 3; i++) strcat(result, "0");
                    strcat(result, freeuse);
                }
                strcpy(mov->objcode, result);
            }
            else if (getSymbol(r1) >= BASE && getSymbol(r1) <= BASE + 4095 && BASE != -1) {//can use BASE relative
                // n = 1, i = 1, x = ?, b = 1, p = 0, e = 0
                if (checkXbit(mov->operand) == 1)
                    strcat(result, "C");
                else
                    strcat(result, "4");
                sprintf(freeuse, "%X", getSymbol(r1) - BASE);
                if (strlen(freeuse) > 3) {
                    for (i = strlen(freeuse) - 3; (unsigned int)i < strlen(freeuse); i++) {
                        k = strlen(result);
                        result[k] = freeuse[i];
                        result[k + 1] = '\0';
                    }
                }
                else {
                    for (i = strlen(freeuse); i < 3; i++) strcat(result, "0");
                    strcat(result, freeuse);
                }
                strcpy(mov->objcode, result);
            }
            else {
                flag = -1;
                printf("Error %d : %s\n", mov->lineNum, line);
                return;
            }
        }
        else printf("1478\n");
    }
    else if (format(mov->opcode) == 4) {// format 4 : b = 0, p = 0, e = 1
        if (r1[0] == '#') { // immediated addressing
            if (r1[1] >= 'A' && r1[1] <= 'Z') { //#LABEL
                for (i = 1; (unsigned int)i < strlen(r1); i++)
                    imad[i - 1] = r1[i];
                if (getopcode(mov->opcode) + 1 < 16) {
                    result[0] = '0';
                    sprintf(result + 1, "%X", getopcode(mov->opcode) + 1);
                }
                else sprintf(result, "%X", getopcode(mov->opcode) + 1);
                if (strcmp(result, "0") == 0) {
                    printf("Error %d : %s\n", mov->lineNum, line);
                    flag = -1;
                    return;
                }
                if (checkXbit(mov->operand) == 1)
                    strcat(result, "9");
                else
                    strcat(result, "1");
                sprintf(freeuse, "%X", getSymbol(imad));
                if (strlen(freeuse) > 5) {
                    for (i = strlen(freeuse) - 5; (unsigned int)i < strlen(freeuse); i++) {
                        k = strlen(result);
                        result[k] = freeuse[i];
                        result[k + 1] = '\0';
                    }
                }
                else {
                    for (i = strlen(freeuse); i < 5; i++) strcat(result, "0");
                    strcat(result, freeuse);
                }
                strcpy(mov->objcode, result);
            }
            else if (r1[1] >= '0' && r1[1] <= '9') { // #Constant
                for (i = 1; (unsigned int)i < strlen(r1); i++)
                    imad[i - 1] = r1[i];
                imad[i - 1] = '\0';
                strcat(result, "1");
                if (getopcode(mov->opcode) + 1 < 16) {
                    result[0] = '0';
                    sprintf(result + 1, "%X", getopcode(mov->opcode) + 1);
                }
                else sprintf(result, "%X", getopcode(mov->opcode) + 1);
                if (checkXbit(mov->operand) == 1)
                    strcat(result, "9");
                else
                    strcat(result, "1");
                sprintf(freeuse, "%X", atoi(imad));
                if (strlen(freeuse) > 5) {
                    for (i = strlen(freeuse) - 5; (unsigned int)i < strlen(freeuse); i++) {
                        k = strlen(result);
                        result[k] = freeuse[i];
                        result[k + 1] = '\0';
                    }
                }
                else {
                    for (i = strlen(freeuse); i < 5; i++) strcat(result, "0");
                    strcat(result, freeuse);
                }
                strcpy(mov->objcode, result);
            }
        }
        else if (r1[0] == '@') {// indirected addressing
            for (i = 1; (unsigned int)i < strlen(r1); i++)
                imad[i - 1] = r1[i];
            if (getopcode(mov->opcode) + 2 < 16) {
                result[0] = '0';
                sprintf(result + 1, "%X", getopcode(mov->opcode) + 2);
            }
            else sprintf(result, "%X", getopcode(mov->opcode) + 2);
            if (strcmp(result, "0") == 0) {
                printf("Error %d : %s\n", mov->lineNum, line);
                flag = -1;
                return;
            }
            if (checkXbit(mov->operand) == 1)
                strcat(result, "9");
            else
                strcat(result, "1");
            sprintf(freeuse, "%X", getSymbol(imad));
            if (strlen(freeuse) > 5) {
                for (i = strlen(freeuse) - 5; (unsigned int)i < strlen(freeuse); i++) {
                    k = strlen(result);
                    result[k] = freeuse[i];
                    result[k + 1] = '\0';
                }
            }
            else {
                for (i = strlen(freeuse); i < 5; i++) strcat(result, "0");
                strcat(result, freeuse);
            }
            strcpy(mov->objcode, result);
        }
        else { // Modification position, n = 1, i = 1 operand is label
            Reloc++;
            for (i = 1; (unsigned int)i < strlen(mov->opcode); i++)
                freeuse[i - 1] = mov->opcode[i];
            freeuse[i - 1] = '\0';
            if (checkOpcode(freeuse) != -1) {
                if (getopcode(mov->opcode) + 3 < 16) {
                    result[0] = '0';
                    sprintf(result + 1, "%X", getopcode(mov->opcode) + 3);
                }
                else sprintf(result, "%X", getopcode(mov->opcode) + 3);
                if (checkXbit(mov->operand) == 1)
                    strcat(result, "9");
                else
                    strcat(result, "1");
                sprintf(freeuse, "%X", getSymbol(r1));
                if (strlen(freeuse) > 5) {
                    for (i = strlen(freeuse) - 5; (unsigned int)i < strlen(freeuse); i++) {
                        k = strlen(result);
                        result[k] = freeuse[i];
                        result[k + 1] = '\0';
                    }
                }
                else {
                    for (i = strlen(freeuse); i < 5; i++) strcat(result, "0");
                    strcat(result, freeuse);
                }
                strcpy(mov->objcode, result);
            }
            else printf("1572\n");
        }
    }
}

unsigned char getopcode(char* s) {//opcode return
    oplist* mov;
    char tmp[100];
    int trash, hash;
    if (s[0] == '+') {
        trash = sscanf(s, "+%s", tmp);
    }
    else strcpy(tmp, s);
    hash = getHash(tmp);
    mov = opcode[hash];
    while (mov != NULL) {
        if (strcmp(tmp, mov->name) == 0)
            return mov->code;
        mov = mov->next;
    }
    hash = trash;
    if (mov == NULL)
        return ' ';
    else return ' ';
}

char* getmn(char* s) {//mn num return
    char a[3], b[3], str[100];
    if (str_chr(s, ',') == 0) {
        if (strcmp(s, "A") == 0) return "00";
        else if (strcmp(s, "X") == 0) return "10";
        else if (strcmp(s, "L") == 0) return "20";
        else if (strcmp(s, "PC") == 0) return "80";
        else if (strcmp(s, "SW") == 0)return "90";
        else if (strcmp(s, "B") == 0)return "30";
        else if (strcmp(s, "S") == 0)return "40";
        else if (strcmp(s, "T") == 0)return "50";
        else if (strcmp(s, "F") == 0)return "60";
        else return " ";
    }
    else if (str_chr(s, ',') == 1) {
        static char result[3];
        strcpy(str, s);
        strcpy(a, strtok(str, ","));
        strcpy(b, strtok(NULL, ","));
        strcpy(a, DeleteleftSpace(a));
        strcpy(b, DeleteleftSpace(b));
        strcpy(a, DeleterightSpace(a));
        strcpy(b, DeleterightSpace(b));

        if (strcmp(a, "A") == 0)result[0] = '0';
        else if (strcmp(a, "X") == 0)result[0] = '1';
        else if (strcmp(a, "L") == 0)result[0] = '2';
        else if (strcmp(a, "PC") == 0)result[0] = '8';
        else if (strcmp(a, "SW") == 0)result[0] = '9';
        else if (strcmp(a, "B") == 0)result[0] = '3';
        else if (strcmp(a, "S") == 0)result[0] = '4';
        else if (strcmp(a, "T") == 0)result[0] = '5';
        else if (strcmp(a, "F") == 0)result[0] = '6';
        else {
            printf("It is not Mnemonic.\n");
            flag = -1;
            return " ";
        }

        if (strcmp(b, "A") == 0)result[1] = '0';
        else if (strcmp(b, "X") == 0)result[1] = '1';
        else if (strcmp(b, "L") == 0)result[1] = '2';
        else if (strcmp(b, "PC") == 0)result[1] = '8';
        else if (strcmp(b, "SW") == 0)result[1] = '9';
        else if (strcmp(b, "B") == 0)result[1] = '3';
        else if (strcmp(b, "S") == 0)result[1] = '4';
        else if (strcmp(b, "T") == 0)result[1] = '5';
        else if (strcmp(b, "F") == 0)result[1] = '6';
        else {
            printf("It is not Mnemonic.\n");
            flag = -1;
            return " ";
        }
        return result;
    }
    else {
        flag = -1;
        printf("Error enter.\n");
        return " ";
    }
}

int checkOpcode(char* str) { // is str in optab
    int hash = getHash(str);
    oplist* mov = opcode[hash];
    if (opcode[hash] == NULL)
        return -1;
    else {
        while (mov != NULL) {
            if (strcmp(mov->name, str) == 0)
                return 0;
            mov = mov->next;
        }
        return -1;
    }
}

int format(char* str) { //Wrong input return -1
    int hash = 0, trash, check = 0;
    char format[100];
    char str_cpy[100];
    str_cpy[0] = '\0';
    format[0] = '\0';
    oplist* mov;

    if (str[0] == '+') { // check format 3 or 4
        trash = sscanf(str, "+%s", str_cpy);
        check = 1;
    }
    else
        strcpy(str_cpy, str);
    if (checkOpcode(str_cpy) == 0) {
        hash = getHash(str_cpy);
        for (mov = opcode[hash]; mov != NULL; mov = mov->next) {
            if (strcmp(mov->name, str_cpy) == 0) {
                strcpy(format, mov->num);
                break;
            }
        }
        if (format[0] != '\0') {
            if (strcmp(format, "3/4") == 0) {
                if (check == 1)
                    return 4;
                else
                    return 3;
            }
            else
                return atoi(format);
        }
	}
	check = trash;
	return -1;
}

void Addsym(char* label, int address) {
    symtab* tmp, * symbol_mov, * link;
    tmp = (symtab*)malloc(sizeof(symtab));
    tmp->address = address;
    strcpy(tmp->name, label);
    tmp->next = NULL;
    if (symbol == NULL) symbol = tmp;
    else {
        symbol_mov = symbol;
        link = symbol;
        while (symbol_mov != NULL) { // Found a location to store the label
            if (compare(symbol_mov->name, tmp->name) == 0) {
                printf("Already label is exist.\n");
                flag = -1;
                return;
            }
            else if (compare(symbol_mov->name, tmp->name) == 1) {
                if (symbol_mov->next == NULL) {
                    symbol_mov->next = tmp;
                    break;
                }
                link = symbol_mov;
                symbol_mov = symbol_mov->next;
            }
            else if (symbol_mov == symbol) {
                tmp->next = symbol;
                symbol = tmp;
                break;
            }
            else if (symbol_mov->next == NULL) {
                tmp->next = symbol_mov;
                link->next = tmp;
                break;
            }
            else {
                tmp->next = link->next;
                link->next = tmp;
                break;
            }
        }
    }
}

void Symbol() {
    symtab* mov = SaveSymbol;
    while (mov != NULL) {
        printf("\t%s\t%04X\n", mov->name, mov->address);
        mov = mov->next;
    }
}

int compare(char* s, char* t) {
    int s_len = strlen(s), t_len = strlen(t);
    int min;
    if (s_len > t_len) min = t_len;
    else min = s_len;

    for (int i = 0; i < min; i++) {
        if ((int)s[i] > (int)t[i]) return -1;
        else if ((int)s[i] < (int)t[i]) return 1;
    }
    if (s_len < t_len) return 1;
    else if (s_len > t_len) return -1;
    else return 0;
}

int getSymbol(char* s) {
    symtab* tmp;
    for (tmp = symbol; tmp != NULL; tmp = tmp->next)
        if (strcmp(tmp->name, s) == 0)
            return tmp->address; //return label's LOCCTR
    if (tmp == NULL)
        return -1;
    else return -1;
}

int checkXbit(char operand[]) {
    char a[100], b[100], str[100];
    a[0] = '\0', b[0] = '\0', str[0] = '\0';
    strcpy(str, operand);
    if (str_chr(str, ',') != 1)
        return -1;
    else {
        strcpy(a, strtok(str, ","));
        strcpy(b, strtok(NULL, ","));
        strcpy(b, DeleteleftSpace(b));
        strcpy(b, DeleterightSpace(b));
        if (strcmp(b, "X") == 0)
            return 1;
        else return -1;
    }
}

void FreeSymtab(symtab* symbol) {
    symtab* mov;
    mov = symbol;
    if (mov == NULL)
        return;
    while (symbol != NULL) {
        mov = symbol;
        symbol = symbol->next;
        free(mov);
    }
}

void Freelistdata() {
    listdata* mov;
    mov = data;
    if (mov == NULL)
        return;
    while (data != NULL) {
        mov = data;
        data = data->next;
        free(mov);
    }
}

void makeOBJ(char* name) {
    char objname[100];
    char intTostring[100];
    char linedata[100];
    char line1[100];
    char end[7];
    int* M = (int*)malloc(sizeof(int) * Reloc);
    linedata[0] = '\0';
    line1[0] = '\0';
    listdata* mov;
    int linecount = 0, flagL = 0, i = 0, x = 0;
    strcpy(objname, name);
    strcat(objname, ".obj");
    FILE* fp = fopen(objname, "w");
    for (mov = data; mov != NULL; mov = mov->next) { // Repeat until the end of the move that stores .asm's data
        if (mov->opcode[0] == '+' && mov->operand[0] != '#' && mov->operand[0] != '@') M[x++] = mov->LOCCTR + 1; // Save location for modification
        if ((linecount + (strlen(mov->objcode) / 2)) > 30 || flagL == -1 || strcmp(mov->opcode, "END") == 0) { // Check the conditions to move on to the next line
            sprintf(intTostring, "%02X", linecount);
            strcat(linedata, intTostring);
            strcat(linedata, line1);
            fprintf(fp, "%s\n", linedata);
            linedata[0] = '\0';
            line1[0] = '\0';
            linecount = 0;
            flagL = 1;
            if (strcmp(mov->opcode, "END") == 0) break; // if opcode is END, break
        }
        if ((strcmp(mov->opcode, "RESW") == 0 || strcmp(mov->opcode, "RESB") == 0) && linecount != 0) flagL = -1; // Conditions to be implemented
        if (linecount == 0 && flagL == 0) { // write H
            sprintf(end, "%06X", mov->LOCCTR);
            strcat(linedata, "H");
            strcat(linedata, mov->label);
            for (i = strlen(linedata); i < 7; i++)
                strcat(linedata, " ");
            sprintf(intTostring, "%06X", mov->LOCCTR);
            strcat(linedata, intTostring);
            sprintf(intTostring, "%06X", LOCCTR);
            strcat(linedata, intTostring);
            fprintf(fp, "%s\n", linedata);
            linedata[0] = '\0';
            flagL = 1;
        }
        else if (mov->label[0] == '.' || mov->objcode[0] == '\0') continue; // Annotation or object code missing
        else if (linecount == 0) { // start textline
            strcat(linedata, "T");
            sprintf(intTostring, "%04X", mov->LOCCTR);
            strcat(linedata, intTostring);//�����ϴ� ������ LOCCTR
            strcat(line1, mov->objcode);
            linecount = strlen(mov->objcode) / 2;
        }
        else {
            strcat(line1, mov->objcode);
            linecount += strlen(mov->objcode) / 2;
        }
    }
    for (i = 0; i < x; i++) { // write M
        strcpy(linedata, "M");
        sprintf(intTostring, "%06X", M[i]);
        strcat(linedata, intTostring);
        strcat(linedata, "05");
        fprintf(fp, "%s\n", linedata);
        linedata[0] = '\0';
    }
    // write E
    strcpy(linedata, "E");
    strcat(linedata, end);
    fprintf(fp, "%s\n", linedata);
    free(M);
    fclose(fp);
}

void makeLIST(char* name) {
    char listname[100];
    listdata* mov;
    strcpy(listname, name);
    strcat(listname, ".lst");
    FILE* fp = fopen(listname, "w");
    for (mov = data; mov != NULL; mov = mov->next) { // Repeat until the end of the move that stores .asm's data
        if (mov->label[0] == '.') { // If Annotation
            fprintf(fp, "%d\t\t%s\t%s %s\n", mov->lineNum, mov->label, mov->opcode, mov->operand);
            continue;
        }
        // If not Annotation
        fprintf(fp, "%d\t", mov->lineNum);
        if (mov->LOCCTR != -1) {
            fprintf(fp, "%04X\t", mov->LOCCTR);
        }
        else {
            fprintf(fp, "\t");
        }
        fprintf(fp, "%s\t%s\t\t%s\t\t%s\n", mov->label, mov->opcode, mov->operand, mov->objcode);
    }
    fclose(fp);
}

char* type(char* name) {
    FILE* fp = NULL;
    struct stat buf;
    DIR* dir = NULL;
    struct dirent* entry = NULL;
    char line[100];
    char filename[100];
    static char str[100];
    str[0] = '\0';
    strcpy(filename, name);
    if (name[4] == ' ') {
        strcpy(filename, strtok(filename, " "));
        strcpy(str, filename);
        strcpy(filename, strtok(NULL, " "));
        strcat(str, " ");
        strcat(str, filename);
        strcpy(filename, DeleteleftSpace(filename));
        strcpy(filename, DeleterightSpace(filename));
    }
    else if (name[4] == '\t') {
        strcpy(filename, strtok(filename, "\t"));
        strcpy(str, filename);
        strcpy(filename, strtok(NULL, "\t"));
        strcat(str, " ");
        strcat(str, filename);
        strcpy(filename, DeleteleftSpace(filename));
        strcpy(filename, DeleterightSpace(filename));
    }
    dir = opendir(".");
    if (dir == NULL) {
        printf("current directory error\n");
	flag = -1;
        return " ";
        exit(1);
    }
    while ((entry = readdir(dir)) != NULL) { // Verify that filename is in the current directory
        lstat(entry->d_name, &buf);
        if(strcmp(filename,entry->d_name)==0){
            fp = fopen(entry->d_name, "r");
            break;
        }
    }
    if (fp == NULL) {
        printf("%s is not exist.\n", filename);
	flag = -1;
        return " ";
    }
    while (fgets(line, sizeof(line), fp) != NULL) { // Output line until end of file
        printf("%s", line);
    }
    fclose(fp);
    closedir(dir);
    return str;
}

void savesymbol() {
    SaveSymbol = (symtab*)malloc(sizeof(symtab));
    SaveSymbol = NULL;
    symtab* mov;
    symtab* tmp;
    for (; symbol != NULL; symbol = symbol->next) { // Save data from symbol as SaveSymbol
        tmp = (symtab*)malloc(sizeof(symtab));
        strcpy(tmp->name, symbol->name);
        tmp->address = symbol->address;
        tmp->next = NULL;
        if (SaveSymbol == NULL) {
            SaveSymbol = tmp;
            continue;
        }
        for (mov = SaveSymbol; mov->next != NULL; mov = mov->next);
        mov->next = tmp;
    }
}
