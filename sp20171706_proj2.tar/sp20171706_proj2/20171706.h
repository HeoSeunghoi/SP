#ifndef __20171706_H__
#define __20171706_H__

typedef struct list { //Structure format to store in the form of a linked list in history
    char hi[100];
    struct list* next;
}list;

typedef struct oplist { //Structure format for storing opcodes in Has table format
    char name[100];
    unsigned char code;
    char num[100];
    struct oplist* next;
}oplist;

typedef struct symtab {
    char name[100];
    int address;
    struct symtab* next;
}symtab;

typedef struct listdata {
    int lineNum;
    int LOCCTR;
    char label[50];
    char opcode[50];
    char operand[50];
    char objcode[10];
    struct listdata* next;
}listdata;

list* hist; //Global variable to save in linek list format
unsigned char shell[65536][16]; //Virtual memory space(1MB)
oplist** opcode; //Global variable to create a hash table
symtab* symbol; // Symbol table used in pass1 and pass2 : pass1�� pass2���� ���Ǵ� symbol table
symtab* SaveSymbol; // When obj and lst are successfully created, the symbol table to save the symbol : obj�� lst�� ���������� �ۼ����� �� symbol�� ������ �� symbol table
listdata* data; // Structure variable to store data in asm : asm�� �����͸� ������ ����ü ����
int adrs = 0; //Save current address to access virtual memory space
int flag = 0; //Variable that determines whether to save in history when input is received
int BASE = -1; // Save Base Locctr
int LOCCTR = 0; // count Locctr
int line_num = 1; // use saveing line number
int Reloc = 0; // count Modification

void history(); //Function to print data stored in hist
void saveHi(char str[]); //A function that stores the refined result in hist when the correct input is received.
char* dump(char str[]); //Function that outputs the correct input value according to the output format
void dir(); //A function that outputs the file in the current directory according to the format when the correct input is received.
void reset(); //A function that initializes all values of the virtual memory shell to 0
char* DeleterightSpace(char* s); //A function that removes all spaces from the right of a string
char* DeleteleftSpace(char* s); //A function that removes all spaces from the left of a string
int str_chr(char* s, char c); //Function that prints the number of specific characters in a string
char* edit(char* str); //A function that changes the data of a specific location in the virtual memory space when the correct input is received.
char* fill(char* str); //Function that changes all data in the corresponding range of virtual memory space when the correct input is received
void readOpcode(); // A function that reads the opcode.txt file and saves the data in the oplist
int getHash(char* s); // Function that uses strings to obtain hash values
unsigned char getopcode(char* s); // Function that returns opcode in optab
char* getmn(char* s); // Function that returns mnemonic
char* mnemonic(char* str); //Function that outputs the code of specific data stored in the oplist when the correct input is received
void opcodeList(); //A function that outputs all data values stored in the oplist according to the format
int range(int x); // A function that checks whether the value of int x is within the range of address
int rangeV(int x); //A function that checks whether the value of int x is within the range of value
void freeList(); //A function that returns all the space stored in the oplist
void freeHi(); //A function that returns all the space stored in the hist
char* assemble(char* str); // make obj and lst file if correct input
void pass1(char* str); // count LOCCTR
void pass2(); // count object code
int checkOpcode(char* str); //check string s is in optable
int format(char* str); // find format
int getSymbol(char* s); // return label's address
void Symbol(); // print label name and address
int compare(char* s, char* t); // compare  char string
void getobjcode(listdata* mov); // Function to obtain and return object code according to format
int checkXbit(char operand[]); // Check if Xbit flag is 1 or 0
void FreeSymtab(symtab* symbol); // free Symbol
void Freelistdata(); // Free listdata
void makeOBJ(char* name); // make obj file
void makeLIST(char* name); // make lst file
char* type(char* name); // print file
void Addsym(char* label, int address); // Add label to symbol
void savesymbol(); // Copy data from symbol to SaveSymbol
#endif